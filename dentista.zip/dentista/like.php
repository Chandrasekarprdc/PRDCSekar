
<?php
	session_start();
	include('config.php');
	$loguserid=$_SESSION['uid'];



	$sqlfetch="SELECT * from posts";
	//echo $sqlfetch;
	$result=$conn->query($sqlfetch);
	while($rowpr=$result->fetch_assoc())
	{

			    $userid=$rowpr['user_id'];
				 $postid=$rowpr['post_id'];
		


		 $sqlctlikes="SELECT count(*) as total from likes  where post_id='$postid'";
		$resultcutlikes=$conn->query($sqlctlikes);
		print_r($resultc);
		 $rowcountlk=$resultcutlikes->fetch_assoc();
		   $total=$rowcountlk['total'];			
?>
			
			
	
				<form method="POST">	
	<span id="ok">LIKE

		<input type="hidden" id="lks_id" value="<?php echo $postid;.?>">
		<input type="hidden" id="lkid" value="<?php echo $userid;?>"> 
	</span>
			<tr>
		<td><img src="uploads/<?php echo $rowpr['post_image'];?>">

		</td>
	</tr>

</form>
<?php  } ?>
	
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	 <script type="text/javascript">
	 	$('#ok').on('click',function(){
	 		alert("fsfsf");
	 			 var lks_id=$('#lks_id').val();
	 			 
	 			 var lkid=$('#lkid').val();
	 			 /alert(lks_id);
	 			var splitt=lks_id.split(",");
	 			alert(splitt[0]);
	 			var splitt1=lkid.split(",");
	 			alert(splitt1);
	 			 var form_data=
	 			
	 			 'lks_id='+(splitt);
	 			alert(lks_id);
	 			 'lkid='+(splitt1);
	 			 alert(form_data);

	 			



	 		
				});
	  			</script>