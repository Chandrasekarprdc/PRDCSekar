<?php
      include('config.php');
	$comment=$_POST['comment'];	
	$com="INSERT into comments(comment)values('".$comment."')";
				echo $com;exit;
			
?>