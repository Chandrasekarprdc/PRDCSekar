<?php
  session_start();
  include('config.php');
  $sql="SELECT * FROM cmt_table";
  $result=$conn->query($sql);
  //print_r($result); 
  $row=$result->fetch_assoc();
?>
<table>
  <tr>
    <td> <?php echo $row['comment'];?></td>
  </tr>
</table>