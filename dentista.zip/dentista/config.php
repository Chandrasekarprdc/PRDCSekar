 <?php
//$servername = "localhost";
//$username = "username";
//$password = "password";
//echo "dhsjhhj";
// Create connection

$conn = new mysqli("localhost", "root", "", "facebook");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
//
//echo "connected";
//$conn = mysqli_connect($servername, $username, $password);
// Check connection
?>