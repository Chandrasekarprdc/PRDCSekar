<?php
    session_start();
    include('config.php');

    $post_id=$_REQUEST['post_id'];
    $user_id=$_REQUEST['user_id'];
    //print_r($post_id);

$sqlcount="SELECT count(*) as total from likes  where post_id='$post_id' and user_id='$user_id'";
        $resultc=$conn->query($sqlcount);
        //print_r($resultc);
        $rowcount=$resultc->fetch_assoc();
        $total=$rowcount['total'];
        //print_r($total);
        if($total==0)
        {

$sql="INSERT into likes(post_id,user_id)values('$post_id','$user_id')";
    echo $sql;
    
$resultd=$conn->query($sql);
    }
    
?>
<script type="text/javascript">
        window.location="like1.php";


</script>
