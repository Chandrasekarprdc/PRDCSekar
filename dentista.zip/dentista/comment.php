<?php
  session_start();
  extract($_REQUEST);
  include('config.php');
      $_SESSION['pst_id']=$_REQUEST['post_id'];
      $_SESION['u_id']=$_REQUEST['user_id'];
?>
<!DOCTYPE html>
<html>
<body>
<form id="forms_id" method="POST">
<textarea rows="4" cols="50" name="cmt_area" id="cmt_area">
</textarea>
<!-- <input type="text" name="cmt_area"> -->
<input type="submit" name="comment" value="comment" id="submit">
<span id="message"></span>
</form>
</body>
</html>
