<?php
session_start();
include('config.php'); 
error_reporting(0);
if($_POST['delete1']=='DELETE')
        {
$checkbox=$_POST['checkAl'];
$sqlmd="DELETE from contact where id in('".implode("','", $_POST['check'])."')";
// echo $sqlmd;
  if($conn->query($sqlmd)==true)
  {
    $rs=1;  
    $mes['succ']="Record successfully Deleted";
      }
      else
      {
        $rs=0;
        $mes['succ']="Please  select checkbox";
      } 
  }


?>
<?php
  session_start();
  error_reporting(0);
  include('config.php');
  $sql="SELECT * from contact where status='0'";
//echo $sql;
  $result=$conn->query($sql);
  //print_r($result);
$row=$result->fetch_assoc();


$sqlctlikes="SELECT count(*) as total from contact";
$resultcm=$conn->query($sqlctlikes);
//print_r($result);
$rowcount=$resultcm->fetch_assoc();
    $total=$rowcount['total'];
?>




<!DOCTYPE html>
<html lang="en">
  <head>
    <title>ContactAs</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
    <div class="py-md-5 py-4 border-bottom">
    	<div class="container">
    		<div class="row no-gutters d-flex align-items-start align-items-center px-3 px-md-0">
    			<div class="col-md-4 order-md-2 mb-2 mb-md-0 align-items-center text-center">
		    		<a class="navbar-brand" href="index.html">ITFMEDIA<span></span></a>
	    		</div><a href="contact.php"></a>
	    		<div class="col-md-4 order-md-1 d-flex topper mb-md-0 mb-2 align-items-center text-md-right">
	    			<div class="icon d-flex justify-content-center align-items-center order-md-last">
	    				
	    			</div>
	    			<div class="pr-md-4 pl-md-0 pl-3 text">
					    
				    </div>
			    </div>
			    <div class="col-md-4 order-md-3 d-flex topper mb-md-0 align-items-center">
			    	<div class="icon d-flex justify-content-center align-items-center"></div>
			    	<div class="text pl-3 pl-md-3">
					    
				    </div>
			    </div>
		    </div>
		  </div>
    </div>
	  <nav class="navbar navbar-expand-lg navbar-dark bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container d-flex align-items-center">
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>
	      <div class="collapse navbar-collapse" id="ftco-nav">
	         <ul class="navbar-nav m-auto">
	        	<li class="nav-item active"><a href="Adminhome.php" class="nav-link pl-0">ADMINHOME</a></li>
            <li class="nav-item active"><a href="Adminposts.php" class="nav-link pl-0">ADMINPOSTS</a></li>
            <li class="nav-item active"><a href="adminprofile.php" class="nav-link pl-0">ADMINPROFILE</a></li>
<li class="nav-item active"><a href="adminnotification.php" class="nav-link pl-0">ADMINNOTIFICATION
          <?php echo $total;?></a></li>
  <li class="nav-item active"><a href="admin.php" class="nav-link pl-0">View Posts</a></li>
            <li class="nav-item active"><a href="Adusercds.php" class="nav-link pl-0">USERVIEWRECORDS</a></li>
            <li class="nav-item active"><a href="logout.php" class="nav-link pl-0">LOGOUT</a></li>

	        </ul> 
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->
    
    <section class="hero-wrap hero-wrap-2" style="background-image: url('images/);" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
            <h1 class="mb-2 bread">Contact as</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="homepg.php">
          </div>
        </div>
      </div>
    </section>
    <div class="success" style="color:red">
      <p align="center"><font size="5"><b>
        <?php
          if($_POST['delete1']=='Delete')
          {
            if($rs==0)
            {
              echo  $mes['succ'];
            }else{
              echo $mes['succ'];
            }
          }
        ?></p></font></b>
      </div>
          <div align="center">
            <center>
                  <?php
                    $sql="SELECT * from contact";
                       $result=$conn->query($sql);
                        if($result>0){
                          ?>
        <table id="app" border="1" bgcolor="lightgreen" width="100%">
          <form method="POST" id="dek" name="dek">
            <thead>
                  <tr>
                    
<th bgcolor="gray"><font color="white"><input type="checkbox" id="checkAl">S.No</font>
  </th>
  <th bgcolor="gray"><font color="white">Id</font></th>
  <th bgcolor="gray"><font color="white">Firstname</font></th>
  <th bgcolor="gray"><font color="white">Email</font></th>
  <th bgcolor="gray"><font color="white">Message</font></th>
  <th bgcolor="gray"><font color="white">Action</font></th>
                  </tr></thead>
                  <tbody>
                    <?php
                      $i=1;

                while($row=$result->fetch_assoc())
                      {
                        $_SESSION['uid']=$row['id'];
                        $img=explode(',',$row['imagefile']);
                        ?>
        <tr>
<td><input type="checkbox" id="checkitem" name="check[]" value="<?php echo $row['id']?>"><?php echo  $i;?></td>
       <td><?php echo $_SESSION['uid']; ?></td>
                            <td><?php echo $row['firstname']; ?></td>
                          <td><?php echo $row['email']; ?></td>
                          <td><?php echo $row['msg']; ?></td>
            <td><a href="delete.php?id=<?php echo $row['id'];?>">Delete</a></td>
                </tr>

                    <?php $i++; } ?>
                      
                  </tbody>
       </table>
       <br/>
       <input type="submit" name="delete1" id="delid" value="DELETE">
          </form>
          <center></center> 
                  <?php
                        }
                          else{
                            echo "0 results";
                          }

                  ?>


            </center>
		    
		<section class="ftco-section bg-light">
			<div class="container">
				<div class="row">
          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="blog-single.html" class="block-20 d-flex align-items-end justify-content-end" style="background-image: url('images/');">
								
              </a>
            
                
                <div class="d-flex align-items-center mt-4">
	              
	              
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="blog-single.html" class="block-20 d-flex align-items-end justify-content-end" style="background-image: url('images/');">
								
              </a>
              <div class="text bg-white p-4">
                
                <div class="d-flex align-items-center mt-4">
	                
	                
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="blog-single.html" class="block-20 d-flex align-items-end justify-content-end" style="background-image: url('images/');">
								
              </a>
              
                
                <div class="d-flex align-items-center mt-4">
	                
	                
	                
	                </p>
                </div>
              </div>
            </div>
          </div>

          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="blog-single.html" class="block-20 d-flex align-items-end justify-content-end" style="background-image: url('images/');">
								<div class="meta-date text-center p-2">
      
                
                <div class="d-flex align-items-center mt-4">
	                
	                
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="blog-single.html" class="block-20 d-flex align-items-end justify-content-end" style="background-image: url('images/');">
								
              </a>
                         
                
                <div class="d-flex align-items-center mt-4">
	                
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="blog-single.html" class="block-20 d-flex align-items-end justify-content-end" style="background-image: url('images/');">								
              </a>
             
                
                <div class="d-flex align-items-center mt-4">
	                
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="row no-gutters my-5">
          <div class="col text-center">
           
          </div>
        </div>
			</div>
		</section>
		
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>