<?php
	session_start();
	include('config.php');
	$sql="SELECT comment FROM cmt_table";
	$result=$conn->query($sql);
	while($row=$result->fetch_assoc()){
				print_r($row);

	}
	
?>