<?php
  session_start();
  include('config.php');
  $sql="SELECT * from posts";
  $result=$conn->query($sql);
  while($row=$result->fetch_assoc())
  {

      $userid=$row['user_id'];
      $postid=$row['post_id'];


      // $sqlctlikes="SELECT count(*) as total from likes where post_id='$postid'";
      // $resultlikes=$conn->query($sqlctlikes);
      // //print_r($resultlikes);
      // $rowcount=$resultlikes->fetch_assoc();
      // $total=$rowcount['total'];
      ?>

      <form method="POST">

<span id='ok'>Like
            <input type="hidden" id="test" value="<?php echo $postid;?>">
               <input type="text" id="utest" value="<?php echo $userid;?>"></span>
            <table>
            <tr>
                <td><img src="uploads/<?php echo $row['post_image'];?>"></td>

            </tr>
</table>

      </form>
      <?php
  }

?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script type="text/javascript">
$('#ok').on('click',function(){
      alert("Hai");
      var test = $("#test").val();
      //alert(test);
        var utest=$("#utest").val();
          //alert(utest);  
          var form_data= 
                'test='+splitt[0],
                '&utest='+splitt1[1];
                alert(form_data);
           

               });
             </script>


<!-- <script>
var splitt=lks.split(','),
            var splitt1=lk.split(',');
            alert(lks_id);
            var form_data=
                'postid='+splitt[0],
               '&userid='+splitt[1];
                $.ajax({
          url: 'likes.php',        
          //POST method is used
          type: "POST",  
          //pass the data        
          data: form_data,        
          //success
          success: function (html) {             
            //if process.php returned 1/true (
          if (html=='success') {      
              $('#message').html('Successfully comment !');
            } else {
            $('#message').html('errosss !');
            }
          }

    
    
  });
    });

  </script>

   
    
      
 -->