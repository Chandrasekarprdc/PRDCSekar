<?php
session_start();
include('config.php');

   
       
       $sqldelpost="DELETE  FROM contact where id='".$_REQUEST['id']."'";
       //echo $sqldelpost;
      if($conn->query($sqldelpost)==True){
      	$_POST=array();
      }
       	//echo $resultp;exit;

?>

