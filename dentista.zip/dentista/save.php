<?php   
session_start();
error_reporting(0);
include "config.php";
error_reporting();
 $loguserid=$_SESSION['uid'];
  $message=array();
  $error=0;



  		 if($_POST['signup'] == 'Submit')
    		{
        
        if ($_POST['firstname'] == '')  {
          $error = 1;
          $message['firstname'] = "Please enter your first name";
        }  else  {
          if (!preg_match("/^[a-zA-Z ]*$/", $_POST['firstname'])) {
            $error = 1;
            $message['firstname'] = "Only letters and white space allowed"; 
            }
       	}


       if ($_POST['email'] == '') {
       $error = 1;
       $message['email'] = "*Please enter your email";
   						} else {
			if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
           $error = 1;
          $message['email'] = "Invalid email";
       }
   }

   	 if ($_POST['password'] == '') {
       $error = 1;
       $message['password']  = "*Please enter your password";
   } else {
       if (!preg_match("/^[0-9]{10}+$/", $_POST['password'])) {
           $error = 1;
       $message['password']  = "*Invalid password";
       }
   }

  				 if($_POST['gender']==''){
  					$error = 1;
    				$message['gender'] = "*No radio buttons were checked.";
  						}
  			 if($_POST['address']==''){
  						$error = 1;
   				 $message['address'] = "No address checked.";
					  }			
					   if($_POST['phoneno']==''){
  						$error = 1;
   				 $message['phoneno'] = "No phoneno checked.";
 							 }			


 	 $target_dir = "uploads/";      

  for($i=0; $i<count($_FILES['image']['name']); $i++){  
  $filename= ($_FILES['image']['name'][$i]);
  $uploadok =1;
  $imagefiletype = strtolower(pathinfo($_FILES['image']['name'][$i], PATHINFO_EXTENSION));
  $imageName = $i.time().'.'.$imagefiletype;
  $target_file = $target_dir .$imageName;

  $newimage[]=$imageName;
if(file_exists($target_file))
  {
      $message['image'] = "Already image exists";
      $uploadok = 0;
  }
  if ($_FILES["image"]["size"][$i] > 500000)
  {
      $message['image'] = "File is too large";
      $uploadok = 0;    
  }

  if($imagefiletype != "jpg" && $imagefiletype != "png" && $imagefiletype != "jpeg"  && $imagefiletype != "gif" )
  {
      $uploadok = 0;
      $message['image'] = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    }
   
  else
  {
      if($_FILES["image"]["tmp_name"][$i] != '') {
         
          move_uploaded_file($_FILES["image"]["tmp_name"][$i], $target_file);
  }
      else
      {
          echo "Error uploading file";    
      }
  }
   
}

      $imgnewfile = implode(',', $newimage);
							 

$sql="INSERT into smd(firstname,email,password,gender,address,phoneno,imagefile)
values('".$_POST['firstname']."','".$_POST['email']."','".$_POST['password']."','".$_POST['gender']."','".$_POST['address']."','".$_POST['phoneno']."','".$imgnewfile."')";
 echo $sql;
$result=$conn->query($sql);

	if($result==1)
{
	echo "Record succesfully";
}
	else{
		echo "failed";


	}
  }


  if($_POST['update'] == 'update')
    {
      
    if ($_POST['firstname'] == '')  {
          $error = 1;
          $message['firstname'] = "Please enter your first name";
        }  else  {
          if (!preg_match("/^[a-zA-Z ]*$/", $_POST['firstname'])) {
            $error = 1;
            $message['firstname'] = "Only letters and white space allowed"; 
            }
        }

         if ($_POST['email'] == '') {
       $error = 1;
       $message['email'] = "*Please enter your email";
   } else {
if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
           $error = 1;
          $message['email'] = "Invalid email";
       }
   }

   if ($_POST['password'] == '') {
       $error = 1;
       $message['password']  = "*Please enter your password";
        } 
   else {
       if (!preg_match("/^[0-9]{10}+$/", $_POST['password'])) {
           $error = 1;
       $message['password']  = "*Invalid password";
       }
        }

if($_POST['gender']==''){
  $error = 1;
    $message['gender'] = "*No radio buttons were checked.";
  }

  	 if($_POST['address']==''){
  			$error = 1;
    $message['address'] = "No address checked.";
  }


  	 if($_POST['phoneno']==''){
  			$error = 1;
    $message['phoneno'] = "No phoneno checked.";
 			 }

 			  $target_dir = "uploads/";
        

    for($i=0; $i<count($_FILES['image']['name']); $i++){
    
$err=1;
    $filename= ($_FILES['image']['name'][$i]);

    $uploadok =1;

    $imagefiletype = strtolower(pathinfo($_FILES['image']['name'][$i], PATHINFO_EXTENSION)); 

    $imageName = $i.time().'.'.$imagefiletype;
    $target_file = $target_dir .$imageName;

    $newimage[]=$imageName;

    


    if(file_exists($target_file))
    {
        $message['image'] = "Already image exists";
        $uploadok = 0;
    }
    if ($_FILES["image"]["size"][$i] > 500000)
    {
        $message['image'] = "File is too large";
        $uploadok = 0;    
    }

    if($imagefiletype != "jpg" && $imagefiletype != "png" && $imagefiletype != "jpeg"  && $imagefiletype != "gif" ) 
    {
        $uploadOk = 0;
        $message['image'] = "Sorry, only JPG, JPEG, PNG & GIF files are allowed."; 
      }
      
    else
    {
        if($_FILES["image"]["tmp_name"][$i] != '') {
            
            move_uploaded_file($_FILES["image"]["tmp_name"][$i], $target_file);
    } 
        else 
        {
            echo "Error uploading file";    
        }
    }
     
 }



        $imgnewfile = $_REQUEST['fullimagename'];
$name=$_POST['name'];

    for($i=0; $i<count($_FILES['image']['name']); $i++){

    $target_dir = "uploads/"; 
    $uploadok =1;       
    $imagefiletype = strtolower(pathinfo($_FILES['image']['name'][$i], PATHINFO_EXTENSION)); 
    $imageName = $i.time().'.'.$imagefiletype;
    $target_file = $target_dir .$imageName;

    $newimage[]=$imageName;

        if($_FILES["image"]["tmp_name"][$i] != '') {
            
           move_uploaded_file($_FILES["image"]["tmp_name"][$i], $target_file);

           
        } 
        else 
        {
            //echo "Error uploading file";    
        }
    
    }

    $newpicture = implode(',', $newimage);


    $filenameh= $imgnewfile.','.$newpicture;

    $filenameh= trim($filenameh,',');

$sql_update = "UPDATE smd SET `firstname` ='".$_POST['firstname']."',`email`='".$_POST['email']."',`password`='".$_POST['password']."',`gender`='".$_POST['gender']."',`address`='".$_POST['address']."',`phoneno`='".$_POST['phoneno']."','". $filenameh."' where id='".$_REQUEST['editid']."'";
echo $sql_update;
   
   $result_up=$conn->query($sql_update);
   
   if($result){
   	echo "Record success update";
   }
   	else{
   		echo "failed";
   	}

  	}
  	if($_POST['delete']=='Delete'){
  		$checkbox=$_POST['checkAl'];
  		$sql_query="Delete from smd where id in('".implode("','", $_POST['check'])."')";
			echo '<script type="text/javascript">alert("deleted")</script>';
  	}


if($_REQUEST['editid']!='')
{
	$sql4="SELECT * from smd where id='".$_REQUEST['editid']."'";
	$result=$conn->query($sql4);
	$row=$result->fetch_assoc();
}


?>
<!DOCTYPE html>
    <html> 
       
    <head>
        <title>User Details</title>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
         </head>

    <body bgcolor="lightgreen" >

        <div>
 
        </div>

         <div class="fst">

<form action="" name="form1" class="add" id="add1" method="POST" enctype="multipart/form-data">

                <center><h2>Enter the data</h2></center>

                <center><table style="width: 80%">

<tr>
                    <td><b>firstname:</b></td>
       <td><input type="text" name="firstname" value="<?php if ($row['firstname'] !='') 
       	{ echo $row['firstname']; } else { echo $_POST['firstname']; } ?>"/>
                 <?php 
				error_reporting(0);
					if($_POST['signup'] == 'Submit')
            					{ ?>  
                  <?php 
						error_reporting(0); 
				echo $message['firstname'];
                  ?>        
               
            <?php } ?>
 </td>
              </tr>

               <tr>
                  <td><label><b>Email:</b></label></td>
 <td><input type="text" name="email" value= "<?php if($row['email'] !='') { echo $row['email']; } else { echo $_POST['email']; } ?>"/> 
              <?php
              if($_POST['signup'] == 'Submit')
            { ?>  
                  <?php echo $message['email'];
                  ?>        
                            <?php } ?>
                            </td>
              </tr>

                 <tr>
                  <td><label><b>Password:</b></label></td>
<td><input type="password" name="password" value= "<?php if($row['password'] !='') 
	{ echo $row['password']; } else { echo $_POST['password']; } ?>"/> 	
						<?php 
          if($_POST['signup'] == 'Submit')
            { ?>  
                  <?php echo $message['password'];
                  ?>        
               
            <?php } ?>
             </td>
              </tr>

              <tr>
<td>
       <label for="gender"><b>Gender</b></label></td>
<td><input type="radio" name="gender" id="gender" value="male" 
		<?php
      if ($row['gender'] == 'male') 
      {
              echo 'checked';
      
      }?>/> Male 
<input type="radio" name="gender" id="gender" value="female" <?php
        if ($row['gender'] == 'female') 
        {
          echo 'checked';
        }
  ?>/> Female 
                                                   
<?php 
         if($_POST['signup'] == 'Submit')
           { ?>  
                 <?php echo  $message['gender'];
                 ?>        
           <?php } ?>
    </td></tr>


     <tr>
        <td><label><b>Address:</b></label></td>
<td><input type="address" name="address" value= "<?php if ($row['address'] !='') 
			{ 
		echo $row['address']; 
		} 
else { echo $_POST['address']; } ?>"/> 


              <?php 
          if($_POST['signup'] == 'Submit')
            { ?>  
                  <?php echo $message['address'];
                  ?>        
               
            <?php } ?>
             </td>
              </tr>


      <tr>
                  <td><label><b>Phoneno:</b></label></td>
<td><input type="phoneno" name="phoneno" value= "<?php if($row['phoneno'] !='') 
	{ echo $row['phoneno']; } else { echo $_POST['phoneno']; } ?>"/> 	
						<?php 
          if($_POST['signup'] == 'Submit')
            { ?>  
                  <?php echo $message['phoneno'];
                  ?>        
               
            <?php } ?>
             </td>
              </tr>


              <tr>
                <td><label><b>File:</b></label></td>
                <div id= "image1" class="image_1">
                

<input type="file" multiple name="image[]" value="$filename"/>
  <input type="hidden" name="fullimagename" value="<?php echo $row['imagefile'];?>">



 <?php 
 			if($_REQUEST['editid'] != '' ) 
                { 


                    $value= explode(',',$row['imagefile']); 
                        
                        if($value[0] !='') {    ?> 
                        
                        <div class="img_div">

  <img src="uploads/<?php echo $value[0];?>" width="100" height="100"></a></td>
                    </div>
                    <?php 
                  }

                        } ?>
                          </div>        
            
            <?php
            if($_POST['signup'] == 'Submit')
                { ?>
                
                        <?php echo $message['imagefile'];
                        ?>
                   
            <?php } ?>
            </td></tr>    


        </center>

    <tr colspan="2">

        <td> 
            <center>

                <?php
                if($_REQUEST['editid'] == '')
                    {
                        ?>
<input type="submit" name="signup" id="signup" value="Submit"> 
                        
                    <?php }
                    ?>
   <?php
            
            if ($_REQUEST['editid'] != '')
                {
                    ?>
<input type="submit" name="update" value="Update">
                <?php } ?>

<input type="hidden"  name="del_id" id="del_id" value ="<?php echo $_REQUEST['editid']; ?>"/>
<?php

        $sql = "SELECT * FROM smd where id='$loguserid'";

         $result = $conn->query($sql); 
         if ($result> 0) {


            ?><table style="width:100%">
                
                <form method="POST" id="dek" name="dek">
                    
  <tr>
  <th bgcolor="lightgray"><input type="checkbox" id="checkAl">S.No</th>
      <th bgcolor="lightgray">firstname</th>
      <th bgcolor="lightgray">Email</th>
      <th bgcolor="lightgray">Password</th>
      <th bgcolor="lightgray">Address</th>
      <th bgcolor="lightgray">Gender</th>
      <th bgcolor="lightgray">Image</th>
      <th  bgcolor="lightgray">Action</th>
                    </tr>

                      <?php 
                    $i = 1;

                    while($row = $result->fetch_assoc()) { 
                    $edit_id = $row['id'];
                  $img = explode(',', $row['imagefile']); 
                        ?>


<tr>
<td><input type="checkbox" id="checkitem" name="check[]" value="<?php echo $row['id']; ?>"><?php echo $i; ?></td>
  <td><?php echo $row['firstname']; ?></td>
  <td><?php echo $row['password']; ?></td>
  <td><?php echo $row['email']; ?></td>
  <td><?php echo $row['address']; ?></td>
<td><?php echo $row['gender']; ?></td>
<td><img src="uploads/<?php echo $row['imagefile'];?>" width="100" height="100"></td>

	<input type="hidden" name="del_id" value="<?php echo $row['id']; ?>"/>
<td><a class="design" id="edit" href="save.php?editid=<?php echo $row['id'];?>">Edit</a>
	<a href="save.php?id=<?php echo $row['id']; ?>">Delete</a></td>
			 </td>

                        </tr>
                        <?php $i++;
                    } ?>
                </table>
                <br/>

<input type="submit" name="delete1" id="delid" value="Delete"></p>
                
            </form>
            
        </center><?php  } ?>


   <!--   else 
    {
        echo "0 results";
    } 
    ?> -->

    </div>

    </body>
    </html>
