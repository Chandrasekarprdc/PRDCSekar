<?php
if($_SESSION['firstname']==NULL)
{

	header('Location:login.php?session=open');
}

?>