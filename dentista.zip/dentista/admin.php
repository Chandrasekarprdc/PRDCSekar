<?php
session_start(); 
include('config.php');
error_reporting(0);
include('check_session.php');
  $loguserid=$_SESSION['uid'];
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <title>View User Posts</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
<div class="py-md-5 py-4 border-bottom">
      <div class="container">
        <div class="row no-gutters d-flex align-items-start align-items-center px-3 px-md-0">
          <div class="col-md-4 order-md-2 mb-2 mb-md-0 align-items-center text-center">
      <a class="navbar-brand" href="index.php">ITFMedia<span></span>
      </a>
      
      <span style="font-size:15px;color:#F00;"><!-- <?php echo $_SESSION['firstname']; ?> --></span>
      
      
          </div>
          <div class="col-md-4 order-md-1 d-flex topper mb-md-0 mb-2 align-items-center text-md-right">
            <div class="icon d-flex justify-content-center align-items-center order-md-last">
              <span class=></span>
            </div>
            <div class="pr-md-4 pl-md-0 pl-3 text">
              <p class="con"><span></span> <span></span></p>
              <p class="con"></p>
            </div>
          </div>
          <?php
         if(empty($_SESSION['id']))
         {
          ?>
      



          <div class="col-md-4 order-md-3 d-flex topper mb-md-0 align-items-center">
            <div class="icon d-flex justify-content-center align-items-center"><span class=></span></div>
            <div class="text pl-3 pl-md-3">
              <p class="hr"><span></span></p>
              <p class="time"><span></span> <span></span> </p>
            </div>
          </div>
          <?php

         }
          
          else
          {
            ?>  

<div class="col-md-4 order-md-3 d-flex topper mb-md-0 align-items-center">
            <div class="icon d-flex justify-content-center align-items-center"><span class="icon-paper-plane"></span></div>
            <div class="text pl-3 pl-md-3">
      <p class="hr"><span><!-- <?php echo $_SESSION['firstname']; ?> --></span></p>
<p class="time"><span><a href=""></a></span> </p>
            </div>
          </div>
          <?php

         }
          ?>



        </div>
      </div>
    </div>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark ftco-navbar-light" id="ftco-navbar">
      <div class="container d-flex align-items-center">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="oi oi-menu"></span> Menu
        </button>
        <div class="collapse navbar-collapse" id="ftco-nav">
          <ul class="navbar-nav m-auto">
            
    
            
        <!--     <li class="nav-item"><a href="find_frds.php" class="nav-link">findfriends</a></li>
        <li class="nav-item"><a href="adminprofile.php" class="nav-link">profile</a></li>
        <li class="nav-item"><a href="addgallery.php" class="nav-link">AddGallery</a></li>
            <li class="nav-item"><a href="notification.php" class="nav-link">
        Notification <?php echo $CountNotificaion; ?></a></li> -->
        <li class="nav-item"><a href="Adminhome.php" class="nav-link">ADMINHOME</a></li> 
        <li class="nav-item"><a href="adminprofile.php" class="nav-link">ADMINPROFILE</a></li>           
        <li class="nav-item"><a href="adminposts.php" class="nav-link">AMDINPOSTS</a></li>
        <li class="nav-item"><a href="adminnotification.php" class="nav-link">ADMNOTIFICATION</a></li>
        <li class="nav-item"><a href="contactas.php" class="nav-link">CONTACTUS</a></li>
        <li class="nav-item"><a href="addgallery.php" class="nav-link">ADDGALLERY</a></li>
        <li class="nav-item"><a href="logout.php" class="nav-link">LOGOUT</a></li>
        

            <li class="nav-item"><a href="" class="nav-link"></a></li>
          </ul>
        </div>
      </div>
    </nav>

    <!-- END nav -->
    <section class="hero-wrap hero-wrap-2" style="background-image: url('images/');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
            <h1 class="mb-2 bread">View User Posts</h1>
            
          </div>
        </div>
      </div>
    </section>
    <section class="home-slider owl-carousel">
      <div class="slider-item" style="background-image:url(images/);" data-stellar-background-ratio="0.5">
        <div class="overlay"></div>
        <div class="container">
          <div class="row no-gutters slider-text align-items-center justify-content-end" data-scrollax-parent="true">
          <div class="col-md-6 text ftco-animate">
             </div>
        </div>
        </div>
      </div>

      <div class="slider-item" style="background-image:url(images/);">
        <div class="overlay"></div>
        <div class="container">
          <div class="row no-gutters slider-text align-items-center justify-content-end" data-scrollax-parent="true">
          <div class="col-md-6 text ftco-animate">
          
          </div>
        </div>
        </div>
      </div>
    </section>
    
    <section class="ftco-section ftco-no-pt ftco-no-pb">
      <div class="container">
        <div class="row no-gutters">
          <div class="col-md-5 p-md-5 img img-2 mt-5 mt-md-0" style="background-image: url(images/);">
          </div>
          <div class="col-md-7 wrap-about py-4 py-md-5 ftco-animate">
            <div class="heading-section mb-5">
              <div class="pl-md-5 ml-md-5 pt-md-5">
                <span class="subheading mb-2"></span>
                <h2 class="mb-2" style="font-size: 32px;"></h2>
              </div>
            </div>
            <div class="pl-md-5 ml-md-5 mb-5">
              <div class="founder d-flex align-items-center mt-5">
                <div class="img" style="background-image: url(images/);"></div>
                <div class="text pl-3">
                  <span class="position"></span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-section ftco-no-pt ftco-no-pb">
      <div class="container-fluid px-md-0">
        <div class="row no-gutters">
          
            
          <div class="col-md-6 d-flex align-items-stretch">
            <div class="consultation consul w-100 px-4 px-md-5">
              <div class="text-center">
                
              </div>
              <form action="#" class="appointment-form">
                <div class="row">
                  <div class="col-md-12 col-lg-6 col-xl-4">
                    <div class="form-group">
                      
                    </div>
                  </div>
                  <div class="col-md-12 col-lg-6 col-xl-4">
                    <div class="form-group">
                      
                    </div>
                  </div>
                  <div class="col-md-12 col-lg-6 col-xl-4">
                    <div class="form-group">
                      <div class="form-field">
                        <div class="select-wrap">
                        
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-12 col-lg-6 col-xl-4">
                    <div class="form-group">
                      <div class="input-wrap">
                        <div class="icon"><span class=></span></div>
                        
                      </div>
                    </div>
                  </div>
                  <div class="col-md-12 col-lg-6 col-xl-4">
                    <div class="form-group">
                      <div class="input-wrap">
                        <div class="icon"><span class=></span></div>
                        
                      </div>
                    </div>
                  </div>
                  
                </div>
              </form>
            </div>
          </div>

          <?php
              if($_POST['delete']=='Delete'){
                if($rs=0){
                  echo $mes['succ'];
                }else{
                  echo $mes['succ'];
                }
              }

            ?>

             <center><h2>Admin Posts page</h2></center>
      
                    </thead>


                    <tbody>
                      <?php
                        include('config.php'); 
                        $sql="SELECT * from posts";
                        $result=$conn->query($sql);

                        ?>
                <form action="" method="POST" enctype="multipart/form-data">     

              <table id="urcds" border="4">
                    <br>
                    <thead>
                      <th>S.no</th>
                          <th>post_id</th>
                            <th>user_id</th>
                              <th>post_image</th>
                              
                                <th>date</th>
                                <th>time</th>
                                <th>Action</th>
                      </tr>

                        </thead>
                        <tbody>
                        <?php
                          //$i=1;
                        while($row=$result->fetch_assoc())
                        {

                                  ?>
                                  <tr>
<td><input type="checkbox" id="checkitem" name="check[]" value="<?php echo $row['id'];?>"><?php echo $i;?></td>
                              <td><?php echo $row['post_id'];?></td>
                              <td><?php echo $row['user_id'];?></td>
                       <td><img src="uploads/<?php echo $row['post_image'];?>"/></td>
                       
                              <td><?php echo $row['date'];?></td>
                              <td><?php echo $row['time'];?></td>
 <td><a href=" admin.php?editid=<?php echo $row['post_id']?>;&&user_id=<?php echo $row['user_id'];?>">EDIT</a>

<td><a href="admin.php?deleteid=<?php echo $row['post_id']?>">Delete</a></td>


                            </tr>
                          </tbody>

                          <?php   
                       //$i++; 
                        }
                        ?>


                              </table>
<input type="submit" name="delete" value="Delete">                                  
                              </form>
                  
                            </div>
        </div>
      </div>
    </section>
          
    <section class="ftco-section ftco-services">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-2">
          <div class="col-md-8 text-center heading-section ftco-animate">
            <span class="subheading"></span>
            
          </div>
        </div>
        <div class="row">
          <div class="col-md-3 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block text-center">
              <div class="icon d-flex justify-content-center align-items-center">
              </div>
              <div class="media-body p-2 mt-3">
               
              </div>
            </div>
          </div>
          <div class="col-md-3 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block text-center">
              <div class="icon d-flex justify-content-center align-items-center">
                <span class=></span>
              </div>
             
            </div>      
          </div>
          <div class="col-md-3 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block text-center">
              <div class="icon d-flex justify-content-center align-items-center">
                <span class=></span>
              </div>
             
            </div>      
          </div>
          
          <div class="col-md-3 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block text-center">
              <div class="icon d-flex justify-content-center align-items-center">
                <span class=></span>
              </div>
             
            </div>
          </div>
          <div class="col-md-3 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block text-center">
              <div class="icon d-flex justify-content-center align-items-center">
                <span class=></span>
              </div>
             
            </div>      
          </div>
          <div class="col-md-3 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block text-center">
              <div class="icon d-flex justify-content-center align-items-center">
                <span class=></span>
              </div>
              
            </div>      
          </div>
          <div class="col-md-3 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block text-center">
              <div class="icon d-flex justify-content-center align-items-center">
                <span class=></span>
              </div>
             
            </div>      
          </div>
          <div class="col-md-3 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block text-center">
              <div class="icon d-flex justify-content-center align-items-center">
              
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-section intro" style="background-image: url(images/);" data-stellar-background-ratio="0.5">
      <div class="container">
        
      </div>
    </section>
    
    <section class="ftco-section">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-2">
          <div class="col-md-8 text-center heading-section ftco-animate">
            </div>
        </div>  
        <div class="row">
          <div class="col-md-6 col-lg-3 ftco-animate">
            <div class="staff">
              <div class="img-wrap d-flex align-items-stretch">
              </div>
              <div class="text pt-3 text-center">
                
              
              </div>
            </div>
          </div>
          <div class="col-md-6 col-lg-3 ftco-animate">
            <div class="staff">
              <div class="img-wrap d-flex align-items-stretch">
                <div class="img align-self-stretch" style="background-image: url(images/doc);"></div>
              </div>
            
            </div>
          </div>
          <div class="col-md-6 col-lg-3 ftco-animate">
            <div class="staff">
              <div class="img-wrap d-flex align-items-stretch">
                <div class="img align-self-stretch" style="background-image: url(images/do);"></div>
              </div>
              
            </div>
          </div>
          <div class="col-md-6 col-lg-3 ftco-animate">
            <div class="staff">
              <div class="img-wrap d-flex align-items-stretch">
                <div class="img align-self-stretch" style="background-image: url(images/do);"></div>
              </div>
              
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-section testimony-section bg-light">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-2">
          <div class="col-md-8 text-center heading-section ftco-animate">
            <span class="subheading"></span>
            <h2 class="mb-4"></h2>
          </div>
        </div>
        <div class="row ftco-animate justify-content-center">
          <div class="col-md-12">
            <div class="carousel-testimony owl-carousel">
              <div class="item">
                <div class="testimony-wrap d-flex">
                  <div class="user-img" style="background-image: url(images/)">
                  </div>
                  <div class="text pl-4 bg-light">
                  <span class="quote d-flex align-items-center justify-content-center">
                     
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap d-flex">
                  <div class="user-img" style="background-image: url(images/)">
                  </div>
                  <div class="text pl-4 bg-light">
                  <span class="quote d-flex align-items-center justify-content-center">
                     
                    
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap d-flex">
              <div class="user-img" style="background-image: url(images/)">
                  </div>
                  <div class="text pl-4 bg-light">
                  <span class="quote d-flex align-items-center justify-content-center">
                    
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap d-flex">
                  <div class="user-img" style="background-image: url(images/)">
                  </div>
                  <div class="text pl-4 bg-light">
                    <span class="quote d-flex align-items-center justify-content-center">
                    
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap d-flex">
                  <div class="user-img" style="background-image: url(images/)">
                  </div>
                  <div class="text pl-4 bg-light">
                    <span class="quote d-flex align-items-center justify-content-center">
                    
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-intro" style="background-image: url(images/);" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row">
          
        </div>
      </div>
    </section>

    <section class="ftco-section">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-2">
           </div>
        <div class="row">
          
          <div class="col-md-3 ftco-animate">
            
          </div>
          <div class="col-md-3 ftco-animate">
            
          </div>
          <div class="col-md-3 ftco-animate">
          
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-section bg-light">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-2">
          
        </div>
        <div class="row">
          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="blog-single.html" class="block-20 d-flex align-items-end justify-content-end" style="background-image: url('images/');">
                <div class="meta-date text">
                  
                </div>
              </a>
             
            </div>
          </div>
          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="blog-single.html" class="block-20 d-flex align-items-end justify-content-end" style="background-image: url('images/i');">
                
              
            </div>
          </div>
          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="blog-single.html" class="block-20 d-flex align-items-end justify-content-end" style="background-image: url('images/');">
                <div class="meta-date text-center">
                 </div>
              </a>
            
            </div>
          </div>
        </div>
      </div>
    </section>

    
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="//cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
 
  <script src="js/main.js"></script>
    
  <script type='text/javascript'>
$(document).ready( function () {
    $('#urcds').DataTable();
    
} );


        </script>


  </body>
</html>