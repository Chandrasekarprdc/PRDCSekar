<?php
session_start();
		if(isset($_SESSION['name'])){
			include('config.php');
			$sql="SELECT * from chat";

		}
?>

