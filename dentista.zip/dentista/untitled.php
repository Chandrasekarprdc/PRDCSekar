<!DOCTYPE html>
<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
<script>
	$(document).on('click','#save',function(e)){

		var data=$("#form-search").serialize();
		$.ajax({

				data:data,
				type:"post",
				url:"save.php",
				success:function(data){
					alert(data);
				}

		});
	}

	<title>serialize</title>
</head>
<body>

</body>
</html>