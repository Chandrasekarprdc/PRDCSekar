 <?php
                      $sql_home= "SELECT * from smd where not id='1'";
                      $result=$conn->query($sql_home);
                      //print_r($result);
                      while($row=$result->fetch_assoc())
                      {   
                        ?>
                        <?php echo $row['firstname'];?>
                        
      <span id="like">
                        <?php
                        $sql_home="SELECT * from posts";
                        $result=$conn->query($sql_home);
                        ?>
                        <form method="POST" id="register_form">
                         <?php
                        while($row_mh=$result->fetch_assoc())
                        {
                           
          $sqlctlikes="SELECT count(*) as total from likes  where post_id='".$row_mh['post_id']."'";
          //echo $sqlctlikes;
          $resultlk=$conn->query($sqlctlikes);
          $rowcount=$resultlk->fetch_assoc();
      //print_r($rowcount);
             $total=$rowcount['total'];
                ?>

<span id="ok" class="span_cls"><h3>Like 
                  </h3>
                  <?php if($total!=0){
                    echo "(".$total.")";
                  }
                  ?>
                  <span id="sm"></span>
                 
                  
<img src="uploads/<?php echo $row_mh['post_image'];?>"/>
<a href="comment1.php?post_id=<?php echo $row_mh['post_id'];?>&&user_id=<?php echo $loguserid;?>">COMMENT</a>
<input type="hidden" name="vals" id="num" value="<?php echo $row_mh['post_id'].",".$row_mh['user_id']?>">
</span>
<?php
}
}
?>
  <?php
    $sql="SELECT * from cmt_table";
    $result=$conn->query($sql);
      while($row=$result->fetch_assoc()){
            //print_r($row);
        ?>
        <?php echo  $_SESSION['comment'];?>
      <?php
      }
    
    ?>