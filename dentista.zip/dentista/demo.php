 if($_POST['update']=='Update')
    {
        if($_POST['firstname']=='')
        {
          $error=1;
          $message['firstname']="*Please enter your firstname";
            }else
            {
              if(!preg_match("/^[a-zA-Z ]*$/", $_POST['firstname'])){
                $error=1;
                $message['firstname']="only letter and white space allowed";
              }
            }
                    if($_POST['email']=='')
                          {
                            $error=1;
                            $message['email']="*please enter your email";
                          }else{
                            if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)){
                              $error=1;
                              $message['email']="Invail email";
                            }
                          } 
                          if($_POST['password']=='')
                          {
                            $error=1;
                            $message['password']="*Please enter the password";
                          }
                          else{
                            if (!preg_match("/^[0-9]{10}+$/", $_POST['password'])) {
                              $error=1;
                              $message['password']="Invaild password";
                            }

                          }
                        if($_POST['gender']=='')
                          {  
                            $error = 1;
                          $message['gender'] = "*No radio buttons were checked.";
                                    }
                            if($_POST['address']==''){
                                    $error = 1;
                                  $message['address'] = "No address checked.";
                                      }
$target_dir = "uploads/";
        

    for($i=0; $i<count($_FILES['image']['name']); $i++){
    
$err=1;
    $filename= ($_FILES['image']['name'][$i]);

    $uploadok =1;

    $imagefiletype = strtolower(pathinfo($_FILES['image']['name'][$i], PATHINFO_EXTENSION)); 

    $imageName = $i.time().'.'.$imagefiletype;
    $target_file = $target_dir .$imageName;

    $newimage[]=$imageName;

    


    if(file_exists($target_file))
    {
        $message['image'] = "Already image exists";
        $uploadok = 0;
    }
    if ($_FILES["image"]["size"][$i] > 500000)
    {
        $message['image'] = "File is too large";
        $uploadok = 0;    
    }

    if($imagefiletype != "jpg" && $imagefiletype != "png" && $imagefiletype != "jpeg"  && $imagefiletype != "gif" ) 
    {
        $uploadOk = 0;
        $message['image'] = "Sorry, only JPG, JPEG, PNG & GIF files are allowed."; 
      }
      
    else
    {
        if($_FILES["image"]["tmp_name"][$i] != '') {
            
            move_uploaded_file($_FILES["image"]["tmp_name"][$i], $target_file);
    } 
        else 
        {
            echo "Error uploading file";    
        }
    }
     
 }



        $imgnewfile = $_REQUEST['fullimagename'];
$name=$_POST['name'];

    for($i=0; $i<count($_FILES['image']['name']); $i++){

    $target_dir = "upload/"; 
    $uploadok =1;       
    $imagefiletype = strtolower(pathinfo($_FILES['image']['name'][$i], PATHINFO_EXTENSION)); 
    $imageName = $i.time().'.'.$imagefiletype;
    $target_file = $target_dir .$imageName;

    $newimage[]=$imageName;

        if($_FILES["image"]["tmp_name"][$i] != '') {
            
           move_uploaded_file($_FILES["image"]["tmp_name"][$i], $target_file);

           
        } 
        else 
        {
            //echo "Error uploading file";    
        }
    
    }

    $newpicture = implode(',', $newimage);


    $filenameh= $imgnewfile.','.$newpicture;

    $filenameh= trim($filenameh,',');

$sqlup = "UPDATE smd SET `firstname`='".$_POST['firstname']."',`email`='".$_POST['email']."',`password`='".$_POST['password']."',`gender`='".$_POST['gender']."',`address`='".$_POST['address']."',`phoneno`='".$_POST['phoneno']."',`imgnewfile`='".$_POST['filenameh']."' where id='".$_REQUEST['editid']."'";
  //echo $sqlup;  

$rwss=$conn->query($sql);
      if($rwss){
        echo "Record successfully";
      }else
      {
        echo "failed";
      }

    }

    if($_POST['delete1']=='DELETE')
    {

      $checkbox=$_POST['checkAl'];
      $sqlde ="Delete from smd where id in('".implode("','",$_POST['check'])."')";
      echo '<script type="text/javascript">alert("deleted")</script>';
    }




      if($_REQUEST['editid']!='')
      {
        $sql4="SELECT * from smd where id='".$_REQUEST['editid']."'";
        //echo $sql4;
          $resultc=$conn->query($sql4);
                $row=$resultc->fetch_assoc();
              $_POST=array();
      }


  ?>
