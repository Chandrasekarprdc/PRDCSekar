<?php
	session_start();
	include('config.php');
	$loguserid=$_SESSION['uid'];



	$sqlfetch="SELECT * from posts";
	//echo $sqlfetch;
	$result=$conn->query($sqlfetch);
	while($rowpr=$result->fetch_assoc())
	{

			$userid=$rowpr['user_id'];
					$postid=$rowpr['post_id'];	

		


		$sqlctlikes="SELECT count(*) as total from likes  where post_id='$postid'";
		$resultcutlikes=$conn->query($sqlctlikes);
		//print_r($resultc);
		$rowcountlk=$resultcutlikes->fetch_assoc();
		  $total=$rowcountlk['total'];			



			?>
				
			<form method="post" id="like1" >
				<div class="loading">

		<table>
			<tr>
		<td><img src="uploads/<?php echo $rowpr['post_image'];?>">

		<td><a href="likes.php?post_id=<?php echo $postid;?>&&user_id=<?php echo $loguserid;?>">
			LIKE (<?php echo $total?>)</a></td>
		<td><a href="comment.php?post_id=<?php echo $postid;?>&&user_id=<?php echo $loguserid;?>">COMMENT</a></td>

				</td>
			</tr>
		</div>
		</table>
		

<?php
	$sql="SELECT *from smd where id='$userid'";
		//echo $sql;
		$resultp=$conn->query($sql);
			//print_r($resultp);
		$row=$resultp->fetch_assoc();







?>
		<td><?php echo $row['firstname'];?>
<?php
	}
?>
 	<script type="text/javascript">
 		$("#submit").click(function)
 		$('.loading').html(loader).fadeIn();
 		var form_data=
 		var postid=$('REQUEST[post_id=post_id]').val();
 		var userid=$('REQUEST[user_id=user_id]').val();
 		var comment=$('input[comment=comment]').val();

 		alert("hi");

</script>






