<?php
include('config.php');
	$sql="SELECT * from posts";
	$result=$conn->query($sql);
	while($row=$result->fetch_assoc())
	{
		//print_r($row);
		?>
		<td><img src="uploads/<?php echo $row['post_image'];?>"/></td>

<?php		
	}

?>