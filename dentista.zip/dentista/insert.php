
	<title></title>
	<style>
	
	span#values {
    cursor: pointer;
        text-decoration: underline;
    color: blue;
        font-size: 21px;''
    font-weight: bold;
}

</style>


<form>
<h2>
<span id='ssssss'>like <input type="hidden" name="all_id" id="all_id" value="1"> </span>
</h2>
</form>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	 <script type="text/javascript">
    

	$('#ssssss').on('click',function(){

	var lks_id = $('#all_id').val();
			//var splitt = lks_id.split(',');
//alert(lks_id);
				var form_data =
				'lks_id='+lks_id;
 						//'p_id='+splitt[0];
 						// '&u_id='+splitt[1];
			//start the ajax
			$.ajax({
				url: 'insert_like.php',				 
				//POST method is used
				type: "POST",	 
				//pass the data        
				data: form_data,				
				//success
				success: function (html) {             
					//if process.php returned 1/true (
					if (html=='success') {			
						$('#message').html('Successfully comment !');
					} else {
					$('#message').html('errosss !');
					}
				}

		
		
	});
		});

	</script>

