

<?php
session_start();
include('config.php');
extract($_REQUEST);
error_reporting(0);
$_SESSION['pst_id'] = $_REQUEST['post_id'];
$_SESSION['u_id'] = $_REQUEST['user_id'];
?>
<!DOCTYPE html>
<html>
    <body>
        <form id="forms_id" method="POST">
            <textarea rows="4" cols="50" name="cmt_area" id="cmt_area"></textarea>
            <!-- <input type="text" name="cmt_area"> -->
            <input type="submit" name="comment" value="comment" id="submit">
            <span id="message"></span>
        </form>
    </body>
</html>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script type="text/javascript">
    $(document).ready(function () {
// var loader='<img src="images/ajax-loader.gif" />';   
        //if submit button is clicked     
        $('#submit').click(function () {
            //show the loader
            //$('.loading').html(loader).fadeIn();		  
            //var cmt = $('#cmt_area').val();
            var cmt = $('textarea[name=cmt_area]').val();
            // var cmt = $('input[name=cmt_area]').val();
            //alert(cmt);

            var form_data =
                    'cmt_area=' + cmt;


            //start the ajax
            $.ajax({

                //this is the php file that processes the data and send mail
                url: "cmt_insert.php",
                //POST method is used
                type: "POST",
                //pass the data        
                data: form_data,
                //success
                success: function (html) {
                    //if process.php returned 1/true (send mail success)
                    if (html == 'success') {
                        //hide the form
                        $('#register_form').fadeOut('slow');
                        //show the success message
                       // $('#message').html('Successfully comment !');
                        //disabled all the text fields
                        $('#cmt_area').attr('disabled', 'true');



                        //if process.php returned 0/false
                    } else {
                        //	$('.loading').fadeOut();						
                        //$('#message').html('Fill comments !');

                    }
                }
            });
            //cancel the submit button default behaviours
            return false;
        });
    });
</script>

