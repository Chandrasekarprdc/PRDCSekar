<?php
include('config.php');
			if(isset($_POST["name")){
			$name=$_POST['name'];
			$age=$_POST['age'];
			$email=$_POSt['email'];
$sql="INSERT into demo(name,age,email)values('".$name."','".$age."','".$email."')";
			echo $sql;
			$result=$conn->query($sql);

		}
?>