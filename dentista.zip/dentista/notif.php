<?php session_start();
      include('config.php'); 
          
              
			 $to_user=$_SESSION['firstname'];
				//print_r($to_user);
			
			
$count_req="SELECT count(*) as numnotify from frd_req where `to_user`='$to_user'";

                      $resultcount=$conn->query($count_req);
                     $rowcount=$resultcount->fetch_assoc();
                    //print_r($rowcount);
                echo $count_result=$rowcount['numnotify'];
				
			
			
			$sql="SELECT * from frd_req where `to_user`='$to_user'";
			//echo $sql;
			$resultre=$conn->query($sql);
					//print_r($resultre);
					while($row=$resultre->fetch_assoc())
					{		//print_r($row);
							 $notifi_from=$row['from_user'];
								
				$sqlcf="SELECT firstname from smd where email='$notifi_from'";
										$result=$conn->query($sqlcf);
										$rowdd=$result->fetch_assoc();
									$notifi_name=$rowdd['firstname'];
									//print_r($notifi_name);
?>
						<div>
							<?php echo $notifi_name;?>ADD friend request
							
						
						</div>
						
						<?php
						
					}
					
					
			?>
				
<?php
	session_start();
	include('config.php');
$sqln="SELECT * from smd where id='".$_SESSION['uid']."'";
//echo $sqln;
	$resulto=$conn->query($sqln);
	//print_r($resulto);
	while($rowt=$resulto->fetch_assoc())
	{		
			 $post_id=$rowt['id'];
		?>	
			<?php
			session_start();
			include('config.php');
				$sqle="SELECT  * from like1 where post_id='".$_SESSION['pid']."'";
				//echo $sqle;
				$resultk=$conn->query($sqle);
				//print_r($resultk);
				while($rowi=$resultk->fetch_assoc())
				{		
				$userid=$rowi['user_id'];
				?>
				<?php
				include('config.php');
				$sqld="SELECT firstname from smd where id='".$_SESSION['uid']."'";
				//echo $sqld;
				$result=$conn->query($sqld);
				//print_r($result);
				$row=$result->fetch_assoc();
				//print_r($row);
					$name=$row['firstname'];
				?>

				<?php
				}
		}

?>
			








	
	
	
	