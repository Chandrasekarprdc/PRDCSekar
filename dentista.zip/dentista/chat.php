<?php
	session_start();
	include('config.php');
	$sqlp="SELECT * from comments";
	$result=$conn->query($sqlp);
	while($rpw=$result->fetch_assoc())
	{
		serialize(print_r($rpw));
	}
?>