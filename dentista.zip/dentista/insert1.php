<?php
	include('config.php');
	$name=$_POST['name'];
	$message=$_POST['message'];
	$sqlquery="INSERT into comment(name,age)values('".$name."','".$message."')";
	echo $sqlquery;
// $result=$conn->query($sqlquery);
	if($conn->query($sqlquery)==True)
	{
		echo "success";
	}else
	{
		echo "Error";
	}
?>