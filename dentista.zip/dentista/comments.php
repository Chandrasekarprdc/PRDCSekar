<?php
session_start();
include('config.php');



				$post_id=$_SESSION['pid'];
			
				$user_id=$_SESSION['uid'];
					$name=$_SESSION['name'];
					$comment=$_POST['comment'];

	

		//echo $sql;
?>
		<?php
	$sql="SELECT comment from comments where post_id='".$_REQUEST['post_id']."' ";
	echo $sql;
			$result=$conn->query($sql);
			//print_r($result);
			while($row=$result->fetch_assoc())
			{
		
			}
		?>

<!DOCTYPE html>
<html>
<head>
	<title>COMMENT PAGE</title>
</head>
<body>
<form method="post">
<input type="text" name="comment" placeholder="Write a comment..." class="comment-text">

	<input type="submit" name="post_comment" value="Enter" class="btn-comment">
</body>
</html>

