<!DOCTYPE html>
<html lang="en">
  <head>
    <title>HOME PAGE</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
    <div class="py-md-5 py-4 border-bottom">
      <div class="container">
        <div class="row no-gutters d-flex align-items-start align-items-center px-3 px-md-0">
          <div class="col-md-4 order-md-2 mb-2 mb-md-0 align-items-center text-center">
            <a class="navbar-brand" href="index.html">ITFMEDIA<span></span></a>
          </div>
          <div class="col-md-4 order-md-1 d-flex topper mb-md-0 mb-2 align-items-center text-md-right">
            
              <span class=""></span>
            </div>
            <div class="pr-md-4 pl-md-0 pl-3 text">
              <p class="con"><span></span> <span></span></p>
              <p class="con"></p>
            </div>
          </div>
          <div class="col-md-4 order-md-3 d-flex topper mb-md-0 align-items-center">
            <span class=""></span></div>
            <div class="text pl-3 pl-md-3">
              <p class="hr"><span></span></p>
              <p class="time"><span></span> <span></span> </p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark ftco-navbar-light" id="ftco-navbar">
      <div class="container d-flex align-items-center">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="oi oi-menu"></span> Menu
        </button>
        <div class="collapse navbar-collapse" id="ftco-nav">
          <ul class="navbar-nav m-auto">
    <li class="nav-item active"><a href="home.php" class="nav-link pl-0">Home</a></li>
            <li class="nav-item"><a href="login.php" class="nav-link">LOGIN</a></li>

      </ul>
        </div>
      </div>
    </nav>
    <!-- END nav -->
    
    <section class="home-slider owl-carousel">
      <div class="slider-item" style="background-image:url(images/f4.jpeg);" data-stellar-background-ratio="0.5">
        <div class="overlay"></div>
        <div class="container">
          <div class="row no-gutters slider-text align-items-center justify-content-end" data-scrollax-parent="true">
          <div class="col-md-6 text ftco-animate">
            <h1 class="mb-4">Only I can change my life. No one can do it for me. <span></span></h1>
            <h3 class="subheading">Believe in yourself!</h3>
            <p><a href="#" class="btn btn-secondary px-4 py-3 mt-3"></a></p>
          </div>
        </div>
        </div>
      </div>

      <div class="slider-item" style="background-image:url(images/f4.jpeg);">
        <div class="overlay"></div>
        <div class="container">
          <div class="row no-gutters slider-text align-items-center justify-content-end" data-scrollax-parent="true">
          <div class="col-md-6 text ftco-animate">
            <h1 class="mb-4">Smile Makes <br>A Lasting Impression</h1>
            <h3 class="subheading">Life is 10% what happens to you and 90% how you react to it.</h3>
            <p><a href="#" class="btn btn-secondary px-4 py-3 mt-3">View our works</a></p>
          </div>
        </div>
        </div>
      </div>
    </section>
    
    <section class="ftco-section ftco-no-pt ftco-no-pb">
      <div class="container">
        <div class="row no-gutters">
          <div class="col-md-5 p-md-5 img img-2 mt-5 mt-md-0" style="background-image: url(images/s3.jpeg);">
          </div>
          <div class="col-md-7 wrap-about py-4 py-md-5 ftco-animate">
            <div class="heading-section mb-5">
              <div class="pl-md-5 ml-md-5 pt-md-5">
                <span class="subheading mb-2">Welcome to ITFMEDIA</span>
                <h2 class="mb-2" style="font-size: 32px;"></h2>
              </div>
            </div>
            <div class="pl-md-5 ml-md-5 mb-5">
              
              
              <div class="founder d-flex align-items-center mt-5">
                <div class="img" style="background-image: url(images/);"></div>
                <div class="text pl-3">
                  <h3 class="mb-0"></h3>
                  <span class="position"> </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-section ftco-no-pt ftco-no-pb">
      <div class="container-fluid px-md-0">
        <div class="row no-gutters">
          <div class="col-md-3 d-flex align-items-stretch">
            
          <div class="col-md-6 d-flex align-items-stretch">
            <div class="consultation consul w-100 px-4 px-md-5">
              <div class="text-center">
                
              </div>
              <form action="#" class="appointment-form">
                <div class="row">
                  <div class="col-md-12 col-lg-6 col-xl-4">
                    <div class="form-group">
                      <input type="text" class="form-control" placeholder="First Name">
                    </div>
                  </div>
                  <div class="col-md-12 col-lg-6 col-xl-4">
                    <div class="form-group">
                      <input type="text" class="form-control" placeholder="Last Name">
                    </div>
                  </div>
                  <div class="col-md-12 col-lg-6 col-xl-4">
                    <div class="form-group">
                      <div class="form-field">
                        <div class="select-wrap">
                          <div class="icon"><span class="ion-ios-arrow-down"></span></div>
                          <select name="" id="" class="form-control">
                            <option value="">Department</option>
                            <option value="">Neurology</option>
                            <option value="">Cardiology</option>
                            <option value="">Dental</option>
                            <option value="">Ophthalmology</option>
                            <option value="">Other Services</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-12 col-lg-6 col-xl-4">
                    <div class="form-group">
                      <div class="input-wrap">
                        <div class="icon"><span class="ion-md-calendar"></span></div>
                        <input type="text" class="form-control appointment_date" placeholder="Date">
                      </div>
                    </div>
                  </div>
                  <div class="col-md-12 col-lg-6 col-xl-4">
                    <div class="form-group">
                      <div class="input-wrap">
                        <div class="icon"><span class="ion-ios-clock"></span></div>
                        <input type="text" class="form-control appointment_time" placeholder="Time">
                      </div>
                    </div>
                  </div>
                  <div class="col-md-12 col-lg-6 col-xl-4">
                    <div class="form-group">
                      
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
          <div class="col-md-3 d-flex align-items-stretch">

          </div>
        </div>
      </div>
    </section>
    

    <section class="ftco-section ftco-services">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-2">
          
        </div>
        <div class="row">
          <div class="col-md-3 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block text-center">
              <div class="icon d-flex justify-content-center align-items-center">
                
              </div>
              
            </div>
          </div>
          <div class="col-md-3 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block text-center">
              <div class="icon d-flex justify-content-center align-items-center">
                
              </div>
              
            </div>      
          </div>
          <div class="col-md-3 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block text-center">
              <div class="icon d-flex justify-content-center align-items-center">
              
              </div>
              
            </div>      
          </div>
          
          <div class="col-md-3 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block text-center">
              <div class="icon d-flex justify-content-center align-items-center">
              
              </div>
              
            </div>
          </div>
          <div class="col-md-3 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block text-center">
              <div class="icon d-flex justify-content-center align-items-center">
              
              </div>
              
            </div>      
          </div>
          <div class="col-md-3 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block text-center">
              <div class="icon d-flex justify-content-center align-items-center">
              
              </div>
              
            </div>      
          </div>
          <div class="col-md-3 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block text-center">
              <div class="icon d-flex justify-content-center align-items-center">
                
              </div>
              
            </div>      
          </div>
          <div class="col-md-3 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block text-center">
              <div class="icon d-flex justify-content-center align-items-center">

              </div>
              
            </div>      
          </div>
        </div>
      </div>
    </section>

   
    
    

    <section class="ftco-section testimony-section bg-light">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-2">
          <div class="col-md-8 text-center heading-section ftco-animate">
            
          </div>
        </div>
        <div class="row ftco-animate justify-content-center">
          <div class="col-md-12">
            <div class="carousel-testimony owl-carousel">
              <div class="item">
                <div class="testimony-wrap d-flex">
                  <div class="user-img" style="background-image: url(images/)">
                  </div>
                  <div class="text pl-4 bg-light">
                  <span class="quote d-flex align-items-center justify-content-center">
                                    </span>
                    
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap d-flex">
                  <div class="user-img" style="background-image: url(images/)">
                  </div>
                  <div class="text pl-4 bg-light">
                    
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap d-flex">
                  <div class="user-img" style="background-image: url(images/)">
                  </div>
                  <div class="text pl-4 bg-light">
                    
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap d-flex">
                  <div class="user-img" style="background-image: url(images/)">
                  </div>
                  <div class="text pl-4 bg-light">

                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap d-flex">
                  <div class="user-img" style="background-image: url(images/)">
                  </div>
                  <div class="text pl-4 bg-light">
                   
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-intro" style="background-image: url(images/bg_3.jpg);" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row">
          <div class="col-md-9">
            <h2>We Provide Free Dental Care Consultation</h2>
            <p class="mb-0">Your Health is Our Top Priority with Comprehensive, Affordable medical.</p>
            <p></p>
          </div>
          <div class="col-md-3 d-flex align-items-center">
            <p class="mb-0"><a href="#" class="btn btn-secondary px-4 py-3">Free Consutation</a></p>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-section">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-2">
          <div class="col-md-8 text-center heading-section ftco-animate">
            
            
            
          </div>
        </div>
        <div class="row">
          <div class="col-md-3 ftco-animate">
            
              <div>
                
              </div>
             
            </div>
          </div>
          <div class="col-md-3 ftco-animate">
            
              <div>
               
              </div>
             
            </div>
          </div>
          <div class="col-md-3 ftco-animate">
            
          </div>
          <div class="col-md-3 ftco-animate">
            
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-section bg-light">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-2">
          <div class="col-md-8 text-center heading-section ftco-animate">
            
            
            
          </div>
        </div>
        <div class="row">
          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="blog-single.html" class="block-20 d-flex align-items-end justify-content-end" style="background-image: url('images/');">
               
              
             
            </div>
          </div>
          
            
          </div>
          
            <div class="blog-entry">
              
             
            </div>
          </div>
        </div>
      </div>
    </section>

    
    
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>