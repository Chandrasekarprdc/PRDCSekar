<?php
session_start();
error_reporting(0);
include('config.php');
include('check_session.php');
$loguserid=$_SESSION['uid'];
$to_user=$_SESSION['firstname'];
?>


<?php

$sqllike="SELECT *  from likes";
//echo $sqllike;

$result=$conn->query($sqllike);
while($row=$result->fetch_assoc()){
 $lik=$row['id'];
  $post_id = $row['post_id'];
  $user_id = $row['user_id'];
  $username_qry = "SELECT firstname FROM `smd` WHERE id=$user_id";
  $username_arr=$conn->query($username_qry);
  while($username_res =$username_arr->fetch_assoc()){
    $username = $username_res['firstname'];
  }
  echo "<div class='like_notif'>$username likes POST $post_id</div>";

$sqlcount="SELECT  count($lik) as total from likes";
$resultcnt=$conn->query($sqlcount);
$rowcount=$resultcnt->fetch_assoc();
 $total=$rowcount['total'];
}

$sql90="SELECT * FROM cmt_table";
  $result15=$conn->query($sql90);
  while($row45=$result15->fetch_assoc()){
        $puid=$row45['post_id'];
        $upid=$row45['user_id'];
        //print_r($row45);
        $commentnot="SELECT firstname from smd where id='$upid'";
        $resultcomment=$conn->query($commentnot); 
            //print_r($resultcomment);
        while($rowtt=$resultcomment->fetch_assoc())
        {
               
              $comment_display=$rowtt['firstname'];
        }//
        echo "<div class='comm_notif'>$comment_display comment your post $puid</div>";
  }
?>





        <?php
        

        $count_req="SELECT count(*)  as numnotify from frd_req  where to_user='$to_user'";
        //echo $count_req;
        $resultre=$conn->query($count_req);
        //print_r($resultre);
        $rowct=$resultre->fetch_assoc();
         $total=$rowct['numnotify'];
        $sqlfr="SELECT * from frd_req where `to_user`='$to_user'";

        $resultre=$conn->query($sqlfr);
        //print_r($resultre);
        while($rowfp=$resultre->fetch_assoc())
        {

            $notifi_from=$rowfp['from_user'];


            $sql="SELECT firstname from smd where email='$notifi_from'";
            //echo $sql;
            $resultre=$conn->query($sql);
                  //print_r($resultre);
            $rowdd=$resultre->fetch_assoc();
            $notifi_name=$rowdd['firstname'];
                    ?>
                    <div><?php echo $notifi_name;?> send to friend request
                    </div>

                    <?php
                   $from_user=$_SESSION['firstname'];
                  
                  $sqlre="SELECT * from frd_req where `from_user`='$from_user'";
                    //echo $sqlre; 
                     $result=$conn->query($sqlre);
                   //print_r($result);exit;
                     while($rowof=$result->fetch_assoc()){
                       //print_r($rowof);
                       $fromuser=$rowof['from_user'];
                        
                        $sql="SELECT firstname from smd where email='$fromuser'";
                        //echo $sql;
                        $result=$conn->query($sql);
                        //print_r($result);
                        $rowdd=$result->fetch_assoc();
                        //print_r($rowdd);
                      $sendreq=$rowdd['firstname'];

                                      }
                                    ?>
         <div><?php echo $sendreq;?></div>Accept friend request

                    <?php
                    }
        ?>






<!DOCTYPE html>
<html>
<head>
<title>notification</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
</head>

<body>
  

  <?php

  $sql1="SELECT count(*) as total from notice WHERE flag='1'"; 
  //echo $sql1;
  $result=$conn->query($sql1);
  //print_r($result);
  while($row=$result->fetch_assoc())
    {

    //print_r($row);
        $vr=$row['total'];
      //echo $vr;   
          }
    ?>
    <button id="class_dropdown" class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Notification(<?php echo $vr;?>)</button>


    <span id="dropdown_id" class="message_show">
      
<?php

    $sql12="SELECT * from notice WHERE flag='1'";
  
  $results=$conn->query($sql12);
  //print_r($result);
  while($row12=$results->fetch_assoc())
    {
      echo $row12['id'];
      echo $row12['title'];
      echo "<br>";
    //print_r($row12);  
      
    }
    ?></span>
      </div> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>
</body>
</html>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
  $(".message_show").hide();
  var count=0;
  $("#class_dropdown").click(function(){
    var click = count++;
    if (click%2==0) {
  //console.log("the click is even");
    $("#dropdown_id").show();
}else{
  $("#dropdown_id").hide();
  }
  });
});
</script>
  



<!DOCTYPE html>
<html lang="en">
  <head>
    <title>NOTIFICATION PAGE</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
    <div class="py-md-5 py-4 border-bottom">
      <div class="container">
        <div class="row no-gutters d-flex align-items-start align-items-center px-3 px-md-0">
          <div class="col-md-4 order-md-2 mb-2 mb-md-0 align-items-center text-center">
      <a class="navbar-brand" href="index.php">ITFMedia<span></span>
      </a>
      
      <span style="font-size:15px;color:#F00;"></span>
        
      
          </div>
          <div class="col-md-4 order-md-1 d-flex topper mb-md-0 mb-2 align-items-center text-md-right">
              <span class=></span>
            </div>
            <div class="pr-md-4 pl-md-0 pl-3 text">
              <p class="con"><span></span> <span></span></p>
              <p class="con"></p>
            </div>
          </div>
          <?php
         if(empty($_SESSION['id']))
         {
          ?>
    <div class="col-md-4 order-md-3 d-flex topper mb-md-0 align-items-center">
            <span class=></span></div>
            <div class="text pl-3 pl-md-3">
              <p class="hr"><span></span></p>
              <p class="time"><span></span> <span></span> </p>
            </div>
          </div>
          <?php

         }
          
          else
          {
            ?>  

<div class="col-md-4 order-md-3 d-flex topper mb-md-0 align-items-center">
            <div class="icon d-flex justify-content-center align-items-center"></div>
            <div class="text pl-3 pl-md-3">
      <p class="hr"><span><!-- <?php echo $_SESSION['firstname']; ?> --></span></p>
<p class="time"><span><a href=""></a></span> </p>
            </div>
          </div>
          <?php

         }
          ?>
        </div>
      </div>
    </div>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark ftco-navbar-light" id="ftco-navbar">
      <div class="container d-flex align-items-center">
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="oi oi-menu"></span> Menu
        </button>
        <div class="collapse navbar-collapse" id="ftco-nav">
          <ul class="navbar-nav m-auto">
  <!-- <li class="nav-item active"><a href="homepg.php" class="nav-link">Home</a></li>
  <li class="nav-item"><a href="register.php" class="nav-link">Register</a></li> -->
            <li class="nav-item active"><a href="home.php" class="nav-link pl-0">HOME</a></li>
            <li class="nav-item active"><a href="posts.php" class="nav-link pl-0">POSTS</a></li>
             <li class="nav-item active"><a href="pro.php" class="nav-link pl-0">PROFILE</a></li>
             <li class="nav-item active"><a href="find_frds.php" class="nav-link pl-0">FINDFRIENDS</a></li>
            <li class="nav-item active"><a href="contact.php" class="nav-link pl-0">CONTACT</a></li>
            <li class="nav-item active"><a href="logout.php" class="nav-link pl-0">LOGOUT</a></li>
          </ul>
        </div>
      </div>
    </nav>
<!-- END nav -->
    
    <section class="hero-wrap hero-wrap-2" style="background-image: url('images/');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
            <h1 class="mb-2 bread">NOTIFICATION</h1>
            
          </div>
        </div>
      </div>
    </section>
    <section class="home-slider owl-carousel">
      <div class="slider-item" style="background-image:url(images/);" 
      data-stellar-background-ratio="0.5">
        <div class="overlay"></div>
        <div class="container">
          <div class="row no-gutters slider-text align-items-center justify-content-end" data-scrollax-parent="true">
          <div class="col-md-6 text ftco-animate">
            <h1 class="mb-4"> <span></span></h1>
            <h3 class="subheading"></h3>
            <p></p>
          </div>
        </div>
        </div>
      </div>

      <div class="slider-item" style="background-image:url(images);">
        <div class="overlay"></div>
        <div class="container">
          <div class="row no-gutters slider-text align-items-center justify-content-end" data-scrollax-parent="true">
          <div class="col-md-6 text ftco-animate">
            <h1 class="mb-4"><br></h1>
            <h3 class="subheading"></h3>
            <p><a href="#" class="btn btn-secondary px-4 py-3 mt-3"></a></p>
          </div>
        </div>
        </div>
      </div>
    </section>
    
    <section class="ftco-section ftco-no-pt ftco-no-pb">
      <div class="container">
        <div class="row no-gutters">
    <div class="col-md-5 p-md-5 img img-2 mt-5 mt-md-0" style="background-image: url(images/);">
          </div>
          <div class="col-md-7 wrap-about py-4 py-md-5 ftco-animate">
            <div class="heading-section mb-5">
              <div class="pl-md-5 ml-md-5 pt-md-5">
                <span class="subheading mb-2"></span>
                <h2 class="mb-2" style="font-size: 32px;"></h2>
              </div>
            </div>
            <div class="pl-md-5 ml-md-5 mb-5">
              <p></p>
              <div class="founder d-flex align-items-center mt-5">
                <div class="img" style="background-image: url(images/);"></div>
                <div class="text pl-3">
                  <h3 class="mb-0"></h3>
                  <span class="position"></span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-section ftco-no-pt ftco-no-pb">
      <div class="container-fluid px-md-0">
        <div class="row no-gutters">
          <div class="col-md-3 d-flex align-items-stretch">
            <div class="consultation w-100 text-center px-4 px-md-5">
              <div>
  
            </div>
            </div>
          </div>
          <div class="col-md-6 d-flex align-items-stretch">
            <div class="consultation consul w-100 px-4 px-md-5">
              <div class="text-center">
              
              </div>
              <form action="#" class="appointment-form">
               </div>
      </div>
    </section>
    

    <section class="ftco-section ftco-services">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-2">
          
        </div>
        <div class="row">
          <div class="col-md-3 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block text-center">
              <div class="icon d-flex justify-content-center align-items-center">
                
              </div>
              
            </div>
          </div>
          <div class="col-md-3 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block text-center">
              <div class="icon d-flex justify-content-center align-items-center">
              </div>
              
            </div>      
          </div>
          <div class="col-md-3 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block text-center">
              <div class="icon d-flex justify-content-center align-items-center">
              
              </div>
              
            </div>      
          </div>
          
          <div class="col-md-3 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block text-center">
              <div class="icon d-flex justify-content-center align-items-center">
                
              </div>
              
            </div>
          </div>
          <div class="col-md-3 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block text-center">
              <div class="icon d-flex justify-content-center align-items-center">
                
              </div>
              
            </div>      
          </div>
          <div class="col-md-3 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block text-center">
              <div class="icon d-flex justify-content-center align-items-center">
                
              </div>
              <div class="media-body p-2 mt-3">
                
              </div>
            </div>      
          </div>
          <div class="col-md-3 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block text-center">
              <div class="icon d-flex justify-content-center align-items-center">
                
              </div>
              <div class="media-body p-2 mt-3">
                
              </div>
            </div>      
          </div>
          <div class="col-md-3 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block text-center">
              <div class="icon d-flex justify-content-center align-items-center">
                
              </div>
              <div class="media-body p-2 mt-3">
                
              </div>
            </div>      
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-section intro" style="background-image: url(images/);" data-stellar-background-ratio="0.5">
      <div class="container">
        <div class="row">
          <div class="col-md-6">
            
          </div>
        </div>
      </div>
    </section>
    
    <section class="ftco-section">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-2">
          <div class="col-md-8 text-center heading-section ftco-animate">
            
      </div>
        </div>  
        <div class="row">
          <div class="col-md-6 col-lg-3 ftco-animate">
            <div class="staff">
              <div class="img-wrap d-flex align-items-stretch">
                <div class="img align-self-stretch" style="background-image: url(images/);"></div>
              </div>
              <div class="text pt-3 text-center">
                
              </div>
            </div>
          </div>
          <div class="col-md-6 col-lg-3 ftco-animate">
            <div class="staff">
              <div class="img-wrap d-flex align-items-stretch">
                <div class="img align-self-stretch" style="background-image: url(images/);"></div>
              </div>
              <div class="text pt-3 text-center">
                
                
                
              </div>
            </div>
          </div>
          <div class="col-md-6 col-lg-3 ftco-animate">
            <div class="staff">
              <div class="img-wrap d-flex align-items-stretch">
                <div class="img align-self-stretch" style="background-image: url(images/);"></div>
              </div>
              
              </div>
            </div>
          </div>
          <div class="col-md-6 col-lg-3 ftco-animate">
            <div class="staff">
              <div class="img-wrap d-flex align-items-stretch">
                <div class="img align-self-stretch" style="background-image: url(images/);"></div>
              </div>
              
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-section testimony-section bg-light">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-2">
          <div class="col-md-8 text-center heading-section ftco-animate">
            <span class="subheading"></span>
            <h2 class="mb-4"></h2>
          </div>
        </div>
        <div class="row ftco-animate justify-content-center">
          <div class="col-md-12">
            <div class="carousel-testimony owl-carousel">
              <div class="item">
                <div class="testimony-wrap d-flex">
                  <div class="user-img" style="background-image: url(images/  )">
                  </div>
                  <div class="text pl-4 bg-light">
                     
                    
                    
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap d-flex">
                  <div class="user-img" style="background-image: url(images/)">
                  </div>
                  <div class="text pl-4 bg-light">
                    <span class="quote d-flex align-items-center justify-content-center">
                      
                    </span>
                    
                    
                      
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap d-flex">
                  <div class="user-img" style="background-image: url(images/)">
                  </div>
                  <div class="text pl-4 bg-light">
                    <span class="quote d-flex align-items-center justify-content-center">
                      
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap d-flex">
                  <div class="user-img" style="background-image: url(images/)">
                  </div>
                  <div class="text pl-4 bg-light">
                    <span class="quote d-flex align-items-center justify-content-center">
                      
                    
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap d-flex">
                  <div class="user-img" style="background-image: url(images/)">
                  </div>
                  <div class="text pl-4 bg-light">
                    <span class="quote d-flex align-items-center justify-content-center">
                    
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-intro" style="background-image: url(images/bg_3.jpg);" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row">
          <div class="col-md-9">
            <h2>We Provide Free Dental Care Consultation</h2>
            <p class="mb-0">Your Health is Our Top Priority with Comprehensive, Affordable medical.</p>
            <p></p>
          </div>
          <div class="col-md-3 d-flex align-items-center">
            <p class="mb-0"><a href="#" class="btn btn-secondary px-4 py-3">Free Consutation</a></p>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-section">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-2">
          <div class="col-md-8 text-center heading-section ftco-animate">
            <span class="subheading"></span>
            <h2 class="mb-4"></h2>
            
          </div>
        </div>
        <div class="row">
          <div class="col-md-3 ftco-animate">
        
          </div>
          <div class="col-md-3 ftco-animate">
            
          </div>
          <div class="col-md-3 ftco-animate">
            
          </div>
          <div class="col-md-3 ftco-animate">
            
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-section bg-light">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-2">
          <div class="col-md-8 text-center heading-section ftco-animate">
            
          </div>
        </div>
        <div class="row">
          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="blog-single.html" class="block-20 d-flex align-items-end justify-content-end" style="background-image: url('images/');">
                
              </a>
             
            </div>
          </div>
          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="blog-single.html" class="block-20 d-flex align-items-end justify-content-end" style="background-image: url('images/');">
    
              </a>
             
            </div>
          </div>
          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="blog-single.html" class="block-20 d-flex align-items-end justify-content-end" style="background-image: url('images/);">
                
              </a>
              <div class="text bg-white p-4">
                <h3 class="heading"><a href="#"></p>
                <div class="d-flex align-items-center mt-4">
                 
                 
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>