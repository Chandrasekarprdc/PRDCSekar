<!DOCTYPE html>
<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
<script>
	$(document).on('click','#save',function(e)){

		var data=$("#form-search").serialize();
		$.ajax({

				data:data,
				type:"POST",
				url:"save.php",
				success:function(data){
					alert(data);
				}

		});
	}
</script>

	<title>serialize</title>
</head>
<body>
<form action="" method="post" id="form-search">
	<input type="text" name="comment" >
	<button id="save" name="save">Serialize form values</button>
	</body>
</html>