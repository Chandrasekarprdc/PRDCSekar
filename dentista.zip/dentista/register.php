  <?php
error_reporting(0);
session_start();
include 'config.php';
$error = 0;
$message=array();
$_SESSION['message']=array();
  $_SESSION['succ']=$message['success'];


if(isset($_POST['submit']) && $_POST['submit']!='')
                    {
                      $firstname=$_POST['firstname'];
                         $email=$_POST['email'];
                      $password=$_POST['password'];
                      $gender=$_POST['gender'];
                      $address=$_POST['address'];
                      $phoneno=$_POST['phoneno'];

                      
                if($_POST['firstname']=='')
                    {
                      $error= 1;
                  $message['firstname'] ="*please enter firstname";
                      }                 
                      else
                        {   
          if(!preg_match("/^[a-zA-Z ]*$/",$_POST['firstname'])) 
                        { 
                      $error=1;          
                    $message['firstname']="Only letters and white space allowed"; 
                             }
                       }

                if($_POST['email']=='') {
        $error=1;
       $message['email']=  "*Please enter your email";
                 }  
                  else
                        {
              if(!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
                        $error=1;       
                          $message['email'] ="Invalid email";
                              }
                        }
                     
                           if($_POST['password'] =='')
         {

        $error=1;
       $message['password'] = "*Please enter your password";
   }
   else
   {
if(!preg_match("/(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{0,6}/",$_POST['password'])) 
{
                $error=1;       
     $message['password'] = "*Invalid password";
       }  
         }


          $gender = $_POST['gender'];
          if(empty($gender))
                {
          $error = 1;
      $message['gender']="gender is required";             
              }


                          $address=$_POST['address'];

                      if(empty($address))
                         {
                            $error = 1;
                        $message['address']="*PLease enter  your address";  

                          }

              $phoneno=$_POST['phoneno'];
                          if(empty($phoneno))
                          {

                              $error=1;
                              $message['phoneno']="*Please enter your phoneno";
                          }
             


$target_dir = "uploads/";      

  for($i=0; $i<count($_FILES['image']['name']); $i++){  
  $filename= ($_FILES['image']['name'][$i]);
  $uploadok =1;
  $imagefiletype = strtolower(pathinfo($_FILES['image']['name'][$i], PATHINFO_EXTENSION));
  $imageName = $i.time().'.'.$imagefiletype;
  $target_file = $target_dir .$imageName;

  $newimage[]=$imageName;
if(file_exists($target_file))
  {
      $message['image'] = "Already image exists";
      $uploadok = 0;
  }
  if ($_FILES["image"]["size"][$i] > 500000)
  {
      $message['image'] = "File is too large";
      $uploadok = 0;    
  }

  if($imagefiletype != "jpg" && $imagefiletype != "png" && $imagefiletype != "jpeg"  && $imagefiletype != "gif" )
  {
      $uploadok = 0;
      $message['image'] = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    }
   
  else
  {
      if($_FILES["image"]["tmp_name"][$i] != '') {
         
          move_uploaded_file($_FILES["image"]["tmp_name"][$i], $target_file);
  }
      else
      {
          echo "Error uploading file";    
      }
  } 
   

}
      $imgnewfile = implode(',', $newimage);


      

 $sql ="INSERT into smd(firstname,email,password,gender,address,phoneno,imagefile) 
 values('".$firstname."','".$email."','".$password."','".$gender."','".$address."',
 '".$phoneno."','".$imgnewfile."')";

//echo $sql;
       if ($conn->query($sql)==TRUE){
       $error =1;
       $_SESSION['succ']="Sucessfully Inserted";
      echo "insert successfully";       //$_POST=array();

    }
        
       else
       {
        
        //echo "Failed";
       }
  


              }

                          ?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Register Page</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
<div class="py-md-5 py-4 border-bottom">
      <div class="container">
        <div class="row no-gutters d-flex align-items-start align-items-center px-3 px-md-0">
          <div class="col-md-4 order-md-2 mb-2 mb-md-0 align-items-center text-center">
      <a class="navbar-brand" href="index.php">ITFMEDIA<span></span>
      </a>
      
      <span style="font-size:15px;color:#F00;"><?php echo $_SESSION['firstname']; ?></span>
      
      
          </div>
          <div class="col-md-4 order-md-1 d-flex topper mb-md-0 mb-2 align-items-center text-md-right">
            
              <span class=></span>
            </div>
            <div class="pr-md-4 pl-md-0 pl-3 text">
              <p class="con"><span></span> <span></span></p>
              <p class="con"></p>
            </div>
          </div>
          <?php
         if(empty($_SESSION['id']))
         {
          ?>
      <div class="col-md-4 order-md-3 d-flex topper mb-md-0 align-items-center">
            
            <div class="text pl-3 pl-md-3">
              <p class="hr"><span></span></p>
              <p class="time"><span></span> <span></span> </p>
            </div>
          </div>
          <?php

         }
          
          else
          {
            ?>  

<div class="col-md-4 order-md-3 d-flex topper mb-md-0 align-items-center">
            <div class="icon d-flex justify-content-center align-items-center"></div>
            <div class="text pl-3 pl-md-3">
      <p class="hr"><span><?php echo $_SESSION['firstname']; ?></span></p>
<p class="time"><span><a href=""></a></span> </p>
            </div>
          </div>
          <?php

         }
          ?>
 </div>
      </div>
    </div>
  
 <nav class="navbar navbar-expand-lg navbar-dark bg-dark ftco-navbar-light" id="ftco-navbar">
      <div class="container d-flex align-items-center">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="oi oi-menu"></span> Menu
        </button>
        <div class="collapse navbar-collapse" id="ftco-nav">
          <ul class="navbar-nav m-auto">
   <li class="nav-item active"><a href="home.php" class="nav-link pl-0">HOME</a></li>
         <li class="nav-item active"><a href="login.php" class="nav-link pl-0">LOGIN</a></li>
          <li class="nav-item active"><a href="register.php" class="nav-link pl-0">REGISTER</a></li>
          <!-- <li class="nav-item active"><a href="logout.php" class="nav-link pl-0">LOGOUT</a></li> -->
          </ul>
        </div>
      </div>
    </nav>
    
    <section class="hero-wrap hero-wrap-2" style="background-image: url('images/');" data-stellar-background-ratio="0.5">
      <div class="overlay">
      <div class="container">
      <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
            <h1 class="mb-2 bread">REGISTER</h1>
            <p class=""><span class="mr-2"><a href="index.php">Home <i class="ion-ios-arrow-forward"></i></a></span> <span><i class="ion-ios-arrow-forward"></i></span></p>
          </div>
        </div>
      </div>
    </section>
		
		<section class="ftco-section ftco-no-pt ftco-no-pb">
			<div class="container">
				<div class="row no-gutters">
					<div class="col-md-5 p-md-5 img img-2 mt-5 mt-md-0" style="background-image: url(images/);">
					</div>
					<div class="col-md-7 wrap-about py-4 py-md-5 ftco-animate">
	          <div class="heading-section mb-5">
	          	<div class="pl-md-5 ml-md-5 pt-md-5">
		          	<!-- <span class="subheading mb-2">Welcome to Dentista</span> -->
		            <h2 class="mb-2" style="font-size: 32px;"> Create New User Registration</h2>
	            </div>
	          </div>
	          <div class="pl-md-5 ml-md-5 mb-5">



              <form class="p-5 " method="POST" enctype="multipart/form-data">
							<div class="form-group">
   <label for="name">firstname </label>
<input type="text" class="form-control" name="firstname"placeholder="firstname" 
            value="">
                          <span style="color:red">
                                    <?php
                        if($_POST['submit']=='Submit')
                                  {
       
                        echo  $message['firstname']; 
                                
                                            }
                                        ?>
                                    </span>
                                      </div>
 
 
   <div class="form-group">
                    <label for="name">Email </label>
<input type="text" class="form-control" name="email" placeholder="email"value="">
      <span  style="color:red">
    <?php 
          if($_POST['submit'] == 'Submit')
                    { 
                   echo $message['email']; 
                   }
                   ?>
                   </span>
                  </div>
          

                   <div class="form-group">
                    <label for="name">Password</label>
<input type="password" class="form-control" placeholder="password" name="password"  value="">
      <span  style="color:red">
    <?php 
        if($_POST['submit'] == 'Submit')
                  { 
                   echo $message['password']; 
                   }
                   ?>
                   </span>
                  </div>

                  <div class="form-group">
  <label for="message">Gender</label>
  <input type="radio" name="gender" value="male" > MALE
  <input type="radio" name="gender"  value= "female"> Female 

                  <span style="color:red">
                  <?php  
                  if($_POST['submit'] == 'Submit'){
                   echo $message['gender'];
                   } ?>
                  </span>

                  </div>




                   <div class="form-group">
                    <label for="message">Address</label>
<input type="text" class="form-control" placeholder="address" name="address" value="">
                  <span  style="color:red">
                  <?php  
                  if($_POST['submit'] == 'Submit'){
                   echo $message['address'];
                   } ?>
                  </span>
                    </div>

                     <div class="form-group">
                    <label for="message">Phoneno</label>
<input type="text" class="form-control" placeholder="phoneno" name="phoneno" value="">
                <span style="color:red">
                  <?php
                  if($_POST['submit']=='Submit')
                              {
                      echo $message['phoneno'];
                                }?>
                                  </span>



   <input type="file" multiple name="image[]" value="$filename"/>
  <input type="hidden" name="fullimagename" value="<?php echo $row['imagefile'];?>">
<input type="submit" value="Submit" id="submit" name="submit" />
                      </form>
                      </div>

                  <div>
              </div>
							
						</div>
					</div>
				</div>
			</div>
		</section>
		
	<!-- 	<section class="ftco-intro" style="background-image: url(images/bg_3.jpg);" data-stellar-background-ratio="0.5">
			<div class="overlay"></div>
			<div class="container">
			
			</div>
		</section> -->

    <section class="ftco-section testimony-section bg-light">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-2">
          <div class="col-md-8 text-center heading-section ftco-animate">
          	
          </div>
        </div>
      </div>
    </section>

		
   
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>