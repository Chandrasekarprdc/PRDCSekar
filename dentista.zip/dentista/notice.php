<?php
include('config.php');
?>

<!DOCTYPE html>
<html>
<head>
<title>notification</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
</head>

<body>
	

	<?php

	$sql1="SELECT count(*) as total from notice WHERE flag='1'"; 
	//echo $sql1;
	$result=$conn->query($sql1);
	//print_r($result);
	while($row=$result->fetch_assoc())
		{

		//print_r($row);
				$vr=$row['total'];
			//echo $vr;		
					}
		?>
		<button id="class_dropdown" class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Notification(<?php echo $vr;?>)</button>


		<span id="dropdown_id" class="message_show">
			
<?php

  	$sql12="SELECT * from notice WHERE flag='1'";
	
	$results=$conn->query($sql12);
	//print_r($result);
	while($row12=$results->fetch_assoc())
		{
			echo $row12['id'];
			echo $row12['title'];
			echo "<br>";
		//print_r($row12);	
			
		}
		?></span>
			



  
</div> 

<?php
	
?>
	<div>
		<?php session_start();
      include('config.php'); 
          $ToUser=$_SESSION['firstname'];
	$count_req="SELECT count(*) as numnotify from frd_req where `to_user`='$ToUser'";
                      $resultcount=$conn->query($count_req);
                     $rowcount=$resultcount->fetch_assoc();
                 $count_result=$rowcount['numnotify'];
				//echo $count_result;
			$sql="SELECT * from frd_req where `to_user`='$ToUser'";
			$resultre=$conn->query($sql);
					while($row=$resultre->fetch_assoc())
					{
								 $notifi_from=$row['from_user'];
								
				$sqlcf="SELECT firstname from smd where email='$notifi_from'";
										$result=$conn->query($sqlcf);
										$rowdd=$result->fetch_assoc();
									$notifi_name=$rowdd['firstname'];
							
?>
						<div>
							<?php echo $notifi_name ;?>ADD friend request
						
						
						</div>
						
						<?php
						
						

							
					}
					
					
					
			
			
			
			

			
		?>
				










	
	
	
	


	</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>
</body>
</html>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
	$(".message_show").hide();
	var count=0;
  $("#class_dropdown").click(function(){
  	var click = count++;
  	if (click%2==0) {
  //console.log("the click is even");
    $("#dropdown_id").show();
}else{
  $("#dropdown_id").hide();
  }
  });
});
</script>
	

