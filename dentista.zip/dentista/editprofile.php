<?php
  session_start();
  include('config.php');
?>
    


<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Editprofile</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body bgcolor="lightgreen">
    <div class="py-md-5 py-4 border-bottom">
    	<div class="container">
    		<div class="row1 no-gutters d-flex align-items-start align-items-center px-3 px-md-0">
    			<div class="col-md-4 order-md-2 mb-2 mb-md-0 align-items-center text-center">
		    		<a class="navbar-brand" href="index.html">ITFMEDIA<span></span></a>
	    		</div>
	    		<div class="col-md-4 order-md-1 d-flex topper mb-md-0 mb-2 align-items-center text-md-right">
	    			<div class="icon d-flex justify-content-center align-items-center order-md-last">
	    				<span class=""></span>
	    			</div>
	    			<div class="pr-md-4 pl-md-0 pl-3 text">
					    <p class="con"><span></span> <span></span></p>
					    <p class="con"></p>
				    </div>
			    </div>
			    <div class="col-md-4 order-md-3 d-flex topper mb-md-0 align-items-center">
			    	<div class="icon d-flex justify-content-center align-items-center"><span class=""></span></div>
			    	<div class="text pl-3 pl-md-3">
					    <p class="hr"><span></span></p>
					    <p class="time"><span></span> <span></span> </p>
				    </div>
			    </div>
		    </div>
		  </div>
    </div>
	  <nav class="navbar navbar-expand-lg navbar-dark bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container d-flex align-items-center">
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>
	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav m-auto">
	        	<li class="nav-item"><a href="index.html" class="nav-link pl-0">Home</a></li>
	        	<li class="nav-item"><a href="about.html" class="nav-link">About</a></li>
	        	<li class="nav-item"><a href="doctor.html" class="nav-link">Doctor</a></li>
	        	<li class="nav-item"><a href="department.html" class="nav-link">Treatments</a></li>
	        	<li class="nav-item"><a href="pricing.html" class="nav-link">Pricing</a></li>
	        	<li class="nav-item active"><a href="editprofile.php" class="nav-link">Blog</a></li>
	          <li class="nav-item"><a href="contact.html" class="nav-link">Contact</a></li>
	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->
    
    <section class="hero-wrap hero-wrap-2" style="background-image: url('images/);" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row1 no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
            <h1 class="mb-2 bread">Blog</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="index.html">Home <i class="ion-ios-arrow1-forward"></i></a></span> <span>Blog <i class="ion-ios-arrow1-forward"></i></span></p>
          </div>
        </div>
      </div>
           <?php
      
       error_reporting(0);
       $message=array();
       $error=0;
          $_SESSION['succ']=$messgae['success'];
          $rsd=0;
          $mes=array();

          if($_POST['update']=='Update')
          {
           
            $firstname=$_POST['firstname'];
            $email=$_POST['email'];
            $password=$_POST['password'];
            $gender=$_POST['gender'];
            $address=$_POST['address'];
            $phoneno=$_POST['phoneno'];
          
              if($_POST['firstname']=='')
              {

                  $error=1;
                  $message['firstname']="Please enter your firstname";
              }else{
                if(!preg_match("/^[a-zA-Z ]*$/", $_POST['firstname'])){
                    $error=1;
                  $message['firstname']= "Only letters and white space allowed";
              }
            }
            

            if($_POST['email']=='')
            {
              $error=1;
              $message['email']="Please enter your email";

            }else{
             if (!filter_var($_POST['mail'], FILTER_VALIDATE_EMAIL)){
              $error=1;
              $message['email']="Invaild email";
             }

            }
              if($_POST['password']=='')
              {

                $error=1;
                $message['password']="Please enter your password";
              }
              else{

                if(!preg_match("/^[0-9]{10}+$/", $_POST['password'])){
                  $error=1;
                  $message['password']="Invaild password";
                }
              }
          

        if($_POST['gender']=='')
        {
          $error=1;
          $message['gender']="No radio buttons were checked";
        }

          
          if($_POST['address']=='')
          {

            $error=1;
            $message['address']="Please enter the address";
          }
          if($_POST['phoneno']=='')
          {
              $error=1;
              $message['phoneno']="Please enter the phoneno";

          }

           $target_dir = "uploads/";
        

    for($i=0; $i<count($_FILES['image']['name']); $i++){
    
$err=1;
    $filename= ($_FILES['image']['name'][$i]);

    $uploadok =1;

    $imagefiletype = strtolower(pathinfo($_FILES['image']['name'][$i], PATHINFO_EXTENSION)); 

    $imageName = $i.time().'.'.$imagefiletype;
    $target_file = $target_dir .$imageName;

    $newimage[]=$imageName;

    


    if(file_exists($target_file))
    {
        $message['image'] = "Already image exists";
        $uploadok = 0;
    }
    if ($_FILES["image"]["size"][$i] > 500000)
    {
        $message['image'] = "File is too large";
        $uploadok = 0;    
    }

    if($imagefiletype != "jpg" && $imagefiletype != "png" && $imagefiletype != "jpeg"  && $imagefiletype != "gif" ) 
    {
        $uploadOk = 0;
        $message['image'] = "Sorry, only JPG, JPEG, PNG & GIF files are allowed."; 
      }
      
    else
    {
        if($_FILES["image"]["tmp_name"][$i] != '') {
            
            move_uploaded_file($_FILES["image"]["tmp_name"][$i], $target_file);
    } 
        else 
        {
            echo "Error uploading file";    
        }
    }
     
 }



        $imgnewfile = $_REQUEST['fullimagename'];
$name=$_POST['name'];

    for($i=0; $i<count($_FILES['image']['name']); $i++){

    $target_dir = "uploads/"; 
    $uploadok =1;       
    $imagefiletype = strtolower(pathinfo($_FILES['image']['name'][$i], PATHINFO_EXTENSION)); 
    $imageName = $i.time().'.'.$imagefiletype;
    $target_file = $target_dir .$imageName;

    $newimage[]=$imageName;

        if($_FILES["image"]["tmp_name"][$i] != '') {
            
           move_uploaded_file($_FILES["image"]["tmp_name"][$i], $target_file);

           
        } 
        else 
        {
            //echo "Error uploading file";    
        }
    
    }

    $newpicture = implode(',', $newimage);


    $filenameh= $imgnewfile.','.$newpicture;

    $filenameh= trim($filenameh,',');







$sql1="Update smd set `firstname`='".$_POST['firstname']."',`email`='".$_POST['email']."',
    `password`='".$_POST['password']."',`gender`='".$_POST['gender']."',`address`='".$_POST['address']."',`phoneno`='".$_POST['phoneno']."',`imagefile`='".$filenameh."' 
    WHERE `id`='".$_REQUEST['del_id']."'";
    //echo $sql1;
    if($conn->query($sql1)==true){
      $error=1;
      $_SESSION['succ']="Successfully Updated";
      $_POST=array();
    }
    else
    {
      $error=0;
      $_SESSION['succ']="failed";
    }
   


   }
   
      $messages=array();
      $rs=0;
      if($_POST['delete1']=='Delete'){
        $sqld= "DELETE from smd where id in('".implode("','", $_POST['check'])."')";  
        if($conn->query($sqld)==true){
          $rs=1;
          $mes['succ']="Record Successfully Deleted";
        }
      }

      if($_REQUEST['editid']!='')
      {
        $sql4= "SELECT * from smd where id='".$_REQUEST['editid']."'";
        $result=$conn->query($sql4);
        $row1=$result->fetch_assoc();

      }
 
       
?>

</section>
    <?php error_reporting(0);
    if($_POST['delete1']=='Delete')
    {
        if($rs==0)
        {
          echo $messages['succ'];
        }
    }
    ?>
<form action="" name="form1" class="add" id="add1" method="POST" enctype="multipart/form-data">
    <center><h2>Edit Profile</h2></center>
    <center>
      <table id="apps" border="4">
        <tr>
          <td><b>Firstname</b></td>
          <td><input type="text" name="firstname" value= "<?php if ($row1['firstname'] !='')   { echo $row1['firstname']; } else { echo $_POST['firstname']; } ?>"/>
            <?php
            error_reporting(0);
            if($_POST['update']=='Update'){
              ?>

              <?php
              error_reporting(0);
              echo $message['firstname'];
              ?>
            
           <?php } ?>
          
        </tr>

         <tr>
                  <td><label><b>Email:</b></label></td>
                  <td><input type="text" name="email" value= "<?php if ($row1['email'] !='') { echo $row1['email']; } else { echo $_POST['email']; } ?>"/> 
              <?php
             
if($_POST['update'] == 'Update')
{ ?>  
                  <?php echo $message['email'];
                  ?>        
                            <?php } ?>
                            </td>
              </tr>

               <tr>
                  <td><label><b>Password:</b></label></td>
<td><input type="password" name="password" value= "<?php if ($row1['password'] !='') { echo $row1['password']; } else { echo $_POST['password']; } ?>"/> 


              <?php 
         
if($_POST['update'] == 'Update')
{ ?>  
                  <?php echo $message['password'];
                  ?>        
               
            <?php } ?>
             </td>
              </tr>


<tr>
<td>
       <label for="gender"><b>Gender</b></label></td>
<td><input  type="radio" name="gender" id="gender" value="male" <?php
      if ($row1['gender'] == 'male') 
      {
              echo 'checked';
      
      }
  ?>/> Male 
<input type="radio" name="gender" id="gender" value="female" <?php
        if ($row1['gender'] == 'female') 
        {
          echo 'checked';
        }
  ?>/> Female 
                                                   
<?php 
         if($_POST['update'] == 'Update')
           { ?>  
                 <?php echo  $message['gender'];
                 ?>        
           <?php } ?>
    </td></tr>



       <tr>
                  <td><label><b>Address:</b></label></td>
                  <td><input type="address" name="address" value= "<?php if ($row1['address'] !='') { echo $row1['address']; } else { echo $_POST['address']; } ?>"/> 
              <?php
             
if($_POST['update'] == 'Update')
{ ?>  
                  <?php echo $message['address'];
                  ?>        
                            <?php } ?>
                            </td>
              </tr>

                 <tr>
                  <td><label><b>Phoneno:</b></label></td>
                  <td><input type="text" name="email" value= "<?php if ($row1['phoneno'] !='') { echo $row1['phoneno']; } else { echo $_POST['phoneno']; } ?>"/> 
              <?php
             
if($_POST['update'] == 'Update')
{ ?>  
                  <?php echo $message['phoneno'];
                  ?>        
                            <?php } ?>
                            </td>
              </tr>
<tr colspan="2">
  <td>
  </td>
</tr>
    <td><label><b>FILE:</b></label>
      <div id="image1" class="image_1">

<input type="file" id="image" class="image" multiple name="img[]" value="$filename">
<input type="hidden" name="fullimagename" value="<?php echo $row['imagefile']; ?>" >

    <center>
          

            <?php   
            if($_REQUEST['editid']!='')
            {
            ?>
<input type="submit"  name="update" value="Update">
  
    <?php  }?>
    <?php if($_REQUEST['editid']=='')
    {
      ?>
     <input type="submit" name="signup" id="signup" value="Submit" class="btn btn-secondary center"></center> 
    <?php } ?>

     

<input type="hidden"  name="del_id" id="del_id" value ="<?php echo $_REQUEST['editid']; ?>"/>
</td>
        </tr>



    </table>
    
    </div>       

      <div class="scnd">
        <br/>
              <center>
                    <?php
                      if($_REQUEST['editid']=='')
                      {
                        
                        ?>
                      <?php } ?>

                      <center><?php

                      $sqlcn="SELECT * FROM smd  WHERE id= '".$_SESSION['uid']."'";

                      $resultcf=$conn->query($sqlcn);
                      //print_r($resultcf);
                        if($resultcf>0){

                          ?><table bgcolor="lightblue">
                            <form method="post" id="dek" name="dek">
                              <center><h2>User profile</h2></center>
              <thead>
                <tr>
<th bgcolor="gray"><font color="white">S.no</font></th>
<th bgcolor="gray"><font color="white">Firstname</font></th>
<th bgcolor="gray"><font color="white">Email</font></th>
<th bgcolor="gray"><font color="white">Password</font></th>
<th bgcolor="gray"><font color="white">Gender</font></th>
<th bgcolor="gray"><font color="white">Address</font></th>
<th bgcolor="gray"><font color="white">Phoneno</font></th>
<th bgcolor="gray"><font color="white">IMAGES</font></th>
<th bgcolor="gary"><font color="white">Action</font></th>


                         </tr>
                            </thead>
                            <tbody>
                                <?php
                                $i=1;
                                while($row1=$resultcf->fetch_assoc())
                                {
                                   $edit_id=$row1['id'];
                                   $img=explode(',', $row1['imagefile']); 
                                   //print_r($img);
                                  ?>

 <tr>
  <td><input type="checkbox" id="checkitem" name="check[]" value="<?php echo $row1['id']; ?>"><?php echo $i; ?></td>
              <td><?php echo $row1['firstname']; ?></td>
             <td><?php echo $row1['email']; ?></td>
              <td><?php echo $row1['password']; ?></td>
              <td><?php echo $row1['gender']; ?></td> 
              <td><?php echo $row1['address'];?></td>
        <td><?php echo $row1['phoneno'];?></td>
        <td><img src="uploads/<?php echo $row1['imagefile'];?>"></td>

<td><a href="editprofile.php?editid=<?php echo $row1['id'];?>" style="text-decoration:none;">Edit</a></br></br>
<a href="editprofile.php?id=<?php echo $row1['id'];?>">Delete</a></td>
</tbody>

                                <?php
                              $i++;
                                ?>


                                <?php
                                  } 
                                ?>
                            </tbody>
                             <?php     
                        }


                      ?>
                        </center></center>
              <input type="submit" name="delete1" id="del_id" value="Delete">
</table>
      </form>
      </body>
		<section class="ftco-section bg-light">
			<div class="container">
				<div class="row1">
          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              
            
                <div>

                <div class="d-flex align-items-center mt-4">
	              
	                
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="blog-single.html" class="block-20 d-flex align-items-end justify-content-end" style="background-image: url('images/');">
								
              </a>
              <div class="text bg-white p-4">
               
                <div class="d-flex align-items-center mt-4">
	             
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="blog-single.html" class="block-20 d-flex align-items-end justify-content-end" style="background-image: url('images/');">
								
              </a>
              <div class="text bg-white p-4">
                
                <div class="d-flex align-items-center mt-4">
	              



                </div>
              </div>
            </div>
          </div>

          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="blog-single.html" class="block-20 d-flex align-items-end justify-content-end" style="background-image: url('images/');">
								
              </a>
              <div class="text bg-white p-4">
                
                <div class="d-flex align-items-center mt-4">
	              
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="blog-single.html" class="block-20 d-flex align-items-end justify-content-end" style="background-image: url('images/');">
								
              </a>
              <div class="text bg-white p-4">
                
                <div class="d-flex align-items-center mt-4">
	              
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="blog-single.html" class="block-20 d-flex align-items-end justify-content-end" style="background-image: url('images/');">
								
              </a>
              <div class="text bg-white p-4">
                
	              
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="row1 no-gutters my-5">
          <div class="col text-center">
            
          </div>
        </div>
			</div>
		</section>
		
    
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>