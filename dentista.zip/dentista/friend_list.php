<?php
	session_start();
	include('config.php');
	  $logusername=$_SESSION['firstname'];

	$sql="SELECT * from frd_req WHERE to_user='$logusername'";
	//echo $sql;
	$result=$conn->query($sql);
	$row=$result->fetch_assoc();
	$recfrd=$row['from_user'];
		?>	
		<?php
		$sqlp="SELECT * from smd where email='$recfrd'";
		$resulte=$conn->query($sqlp);
		$rowc=$resulte->fetch_assoc();
			?>	

			<td><?php echo $rowc['firstname'];?></td>