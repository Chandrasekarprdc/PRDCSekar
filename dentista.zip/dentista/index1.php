<!DOCTYPE html>
<html>
 
<head>
    <title>How to Insert Data Using jQuery & Ajax serialize Method in PHP</title>
</head>
<body>
<form id="insert_data" method="POST">

<label>Name</label>
<input type="text" name="name" id="name" />
<br/>
<label>Age</label>
<input type="text" name="age" id="age" />
<br/>
<br/>
<label>Email</label>
<input type="text" name="email" id="email" />
<br/>
<input type="submit" name="submit" id="submit" value="Submit" />
</form>

<div id="return"></div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<script>
$(document).ready(function() {
$('#submit').click(function() {
var name = $('#name').val();
var age = $('#age').val();
var email = $('#email').val();
$.ajax({
	url: "insert2.php",
method: "POST",
data: $('#insert_data').serialize(),
success: function(data) {


}
});

});
});
</script>
</script>
</body>
	</html>