<?php
	session_start();
	include('config.php');
	date_default_timezone_set("Asia/Kolkata");
  	$user_id=$_SESSION['uid'];
	$date=date('Y-m_d');
	 $time=date('g:i a');

			$target_dir = "uploads/";      

  for($i=0; $i<count($_FILES['image']['name']); $i++){  
  $filename= ($_FILES['image']['name'][$i]);
  $uploadok =1;
  $imagefiletype = strtolower(pathinfo($_FILES['image']['name'][$i], PATHINFO_EXTENSION));
  $imageName = $i.time().'.'.$imagefiletype;
  $target_file = $target_dir .$imageName;

  $newimage[]=$imageName;
if(file_exists($target_file))
  {
      $message['image'] = "Already image exists";
      $uploadok = 0;
  }
  if ($_FILES["image"]["size"][$i] > 500000)
  {
      $message['image'] = "File is too large";
      $uploadok = 0;    
  }

  if($imagefiletype != "jpg" && $imagefiletype != "png" && $imagefiletype != "jpeg"  && $imagefiletype != "gif" )
  {
      $uploadok = 0;
      $message['image'] = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    }
   
  else
  {
      if($_FILES["image"]["tmp_name"][$i] != '') {
         
          move_uploaded_file($_FILES["image"]["tmp_name"][$i], $target_file);
  }
      else
      {
          echo "Error uploading file";    
      }
  } 
   

}
      $imgnewfile = implode(',', $newimage);



$sqlposts="INSERT INTO posts(user_id,post_image,message,date,time)values
('$user_id','".$imgnewfile."','$date','$time')";
echo $sqlposts;


?>
<!DOCTYPE html>
<html>
<head>
	<title>POST TABLE</title>
</head>
<body>
	 <form class="p-5 " method="POST" enctype="multipart/form-data">
		<input type="file" multiple name="image[]" value="$filename"/>
  <input type="hidden" name="fullimagename" value="<?php echo $row['post_image'];?>">
<input type="submit" value="Submit" id="submit" name="submit" />


	</form>

</body>
</html>

