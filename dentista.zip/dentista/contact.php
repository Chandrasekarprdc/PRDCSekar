
<?php
    session_start();
      error_reporting(0);
        include('config.php');
        include('check_session.php');
              $message=array();
                  $error=1;
                    $_SESSION['succ']=$message['success'];
                        $message=array();
                        $rs=0;
                        $id=$_SESSION['uid'];

                        if(isset($_POST['submit'])=='Submit')
                        {
                           
                            $firstname=$_POST['firstname'];
                            $email=$_POST['email'];
                            $msg=$_POST['msg'];
                            if(empty($_POST['firstname']))
                            {
                              $error=1;
                              $message['firstname']="*Please enter the firstname";
                            }
                            else{
                          if(!preg_match("/^[a-z.A-Z ]*$/", $_POST['firstname'])){
                               $error=1;          
                          $message['firstname']="Only letters and white space allowed"; 
                              }
                          }
                            
                           if (empty($_POST['email']))  {
                                    $error=1;
                            $message['email'] ="*Please enter email";
                              }  else{
                  if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL))  {
                                    $error=1;          
                                   $message['email']="Invalid email"; 
                                }
                            }
                            if (empty($_POST['msg']))  {
                                  $error=1;
                        $message['msg'] ="*Please enter Message";
                    }           else{
                    if (!preg_match("/^[a-z.A-Z.0-9 ]*$/", $_POST['msg'])) {
                            $error=1;          
                  $message['msg']="Invalid message"; 
            }
        }
            //if(empty($_POST['status']))

$sql1="INSERT into contact(firstname,email,msg,status)
values('".$_POST['firstname']."','".$_POST['email']."','".$_POST['msg']."','0')";
//echo $sql1;
if($conn->query($sql1)==True){
      $error=1;
    echo "Inserted Successfully";

}
else{
  echo "Failed";
}
}



?>
<?php

$sqllike="SELECT *  from likes";
//echo $sqllike;

$result=$conn->query($sqllike);
while($row=$result->fetch_assoc())
{ 
    $_SESSION['like']=$row['id'];
  $lik=$_SESSION['like'];
  $count_like="SELECT count($lik) as total from likes";
//  echo $count_like;
  $result=$conn->query($count_like);
  $rowcount=$result->fetch_assoc();
      $total=$rowcount['total'];

  ?>
  <?php
  }
  ?>

    <?php
  $sqlcmt="SELECT * from cmt_table";
  $resultcm=$conn->query($sqlcmt);
  while($rowcomm=$resultcm->fetch_assoc()){
       $_SESSION['cmt']=$rowcomm['comment_id'];
       $count="SELECT count(*) as total_cmt from cmt_table";
       //echo $count;     
       $resultcm=$conn->query($count);
       $rowcount_cmt=$resultcm->fetch_assoc();
       $totalcmt=$rowcount_cmt['total_cmt'];
}
  ?>



<!DOCTYPE html>
<html lang="en">
  <head>
    <title>CONTACT PAGE</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
    <div class="py-md-5 py-4 border-bottom">
    	<div class="container">
    		<div class="row no-gutters d-flex align-items-start align-items-center px-3 px-md-0">
    			<div class="col-md-4 order-md-2 mb-2 mb-md-0 align-items-center text-center">
		    		<a class="navbar-brand" href="index.php">ITFMEDIA<span></span></a>
	    		</div>
	    		<div class="col-md-4 order-md-1 d-flex topper mb-md-0 mb-2 align-items-center text-md-right">
	    			<div class="icon d-flex justify-content-center align-items-center order-md-last">
	    				
	    			</div>
	    			<div class="pr-md-4 pl-md-0 pl-3 text">
					    
				    </div>
			    </div>
			    <div class="col-md-4 order-md-3 d-flex topper mb-md-0 align-items-center">
			    	<div class="icon d-flex justify-content-center align-items-center"></div>
			    	<div class="text pl-3 pl-md-3">
					    <p class="hr"><span></span></p>
					    <p class="time"><span></span> <span></span> </p>
				    </div>
			    </div>
		    </div>
		  </div>
    </div>
	  <nav class="navbar navbar-expand-lg navbar-dark bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container d-flex align-items-center">
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>
	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav m-auto">
	        	<li class="nav-item active"><a href="home.php" class="nav-link pl-0">HOME</a></li>
            <li class="nav-item active"><a href="posts.php" class="nav-link pl-0">POSTS</a></li>
            <li class="nav-item active"><a href="pro.php" class="nav-link pl-0">PROFILE</a></li>
            <li class="nav-item active"><a href="find_frds.php" class="nav-link pl-0">FINDFRIENDS</a></li>
            <li class="nav-item active"><a href="notification.php" class="nav-link pl-0">NOTIFICATION
              <span><?php echo $total;?></a></li>
	          <li class="nav-item active"><a href="logout.php" class="nav-link pl-0">LOGOUT</a></li>
	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->
    
    <section class="hero-wrap hero-wrap-2" style="background-image: url('images/');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
            <h1 class="mb-2 bread">Contact</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="index.php"></a>
          </div>
        </div>
      </div>
    </section>
    <div class="success" style="color:red">
      <p align="center"><font size="5"><b>
      <?php
        if($_SESSION['succ']!=''){
          echo "<span style='color:green'>".$_SESSION['succ']."</span>";
          $_SESSION['succ']='';unset($_SESSION['succ']);
            }else if($_SESSION['error']!=''){
              echo "<span style='color:green'>".$_SESSION['succ']."</span>";
              $_SESSION['error']='';
            }
            ?>
              </b></font></p>

		
		<section class="ftco-section ftco-no-pt ftco-no-pb contact-section">
			<div class="container">
				<div class="row d-flex align-items-stretch no-gutters">
					<div class="col-md-6 p-4 p-md-5 order-md-last bg-light">
						<form action="" method="POST">
              <div class="form-group">
                <label>FIRSTNAME</label>
      <input type="text" name="firstname" value="<?php if ($row['firstname']!='')
           {
                  echo $row['firstname'];

          } else
          {
            echo $_POST['firstname'];
          }
            ?>">
            <span style="color:red">

              <?php
              error_reporting(0);
              $error=1;
              if ($_POST['submit']=='Submit') {
                echo $message['firstname'];
                
              }

              ?>

              <div class="form-group">
      <label>EMAIL</label>
      <input type="text" name="email" value="<?php if ($row['email']!='')
           {
                  echo $row['email'];

          } else
          {
            echo $_POST['email'];
          }
            ?>">
            <span style="color:red">

              <?php
              error_reporting(0);
              $error=1;
              if ($_POST['submit']=='Submit') {
                echo $message['email'];
                
              }

              ?>

              </div>

              <div class="form-group">
                             <label>Textarea</label>
<textarea type="text" class="form-group" placeholder="message" name="msg" 
value="<?php if($row['msg']!='')
          {
    echo $row['msg']; 
          }else{
            echo $_POST['msg'];
          }

?>"></textarea>
            <span style="color:red">  
              <?php
              error_reporting(0);
              $error=1;
              if($_POST['submit']=='Submit')
              {
                echo $message['msg'];
              }
              ?>
  
            </span>
              </div>
              <div class="form-group">
        <input type="submit" name="submit" value="Submit">               
              </div>


                  </div>
                
              </div>

            </form>
					</div>

				</div>
			</div>
		</section>
		
		<section class="ftco-section contact-section">
      <div class="container">
        <div class="row d-flex mb-5 contact-info">
          <div class="col-md-12 mb-4">
           
          </div>
          <div class="w-100"></div>
          <div class="col-md-3 d-flex">
          	<div class="bg-light d-flex align-self-stretch box p-4">
	         
	          </div>
          </div>
          <div class="col-md-3 d-flex">
          	<div class="bg-light d-flex align-self-stretch box p-4">
	         
	          </div>
          </div>
          <div class="col-md-3 d-flex">
          	<div class="bg-light d-flex align-self-stretch box p-4">
	         
	          </div>
          </div>
          <div class="col-md-3 d-flex">
          	<div class="bg-light d-flex align-self-stretch box p-4">
	         
	          </div>
          </div>
        </div>
      </div>
    </section>
		
    
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>