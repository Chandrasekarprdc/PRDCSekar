<?php
  session_start();
  error_reporting(0);
  include('config.php');
  include('check_session.php');
?>
<?php
$sqllike="SELECT *  from likes";
//echo $sqllike;

$result=$conn->query($sqllike);
while($row=$result->fetch_assoc())
{ 
    $_SESSION['like']=$row['id'];
   $lik=$_SESSION['like'];
  $count_like="SELECT count($lik) as total from likes";
//  echo $count_like;
  $result=$conn->query($count_like);
  $rowcount=$result->fetch_assoc();
      $total=$rowcount['total'];
      ?>

  <?php
  }
  ?>

  <?php
  $sqlcmt="SELECT * from cmt_table";
  $resultcm=$conn->query($sqlcmt);
  while($rowcomm=$resultcm->fetch_assoc()){
       $_SESSION['cmt']=$rowcomm['comment_id'];
       $count="SELECT count(*) as total_cmt from cmt_table";
       //echo $count;     
       $resultcm=$conn->query($count);
       $rowcount_cmt=$resultcm->fetch_assoc();
       $totalcmt=$rowcount_cmt['total_cmt'];
}
  ?>



<!DOCTYPE html>
<html>
<head>
	
    <title>Post Table</title>
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
 <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>


    <div class="py-md-5 py-4 border-bottom">
      <div class="container">
        <div class="row no-gutters d-flex align-items-start align-items-center px-3 px-md-0">
          <a href="timeline.php"></a>
          <div class="col-md-4 order-md-2 mb-2 mb-md-0 align-items-center text-center">
            <a class="navbar-brand" href="index.html">ITFMEDIA<span></span></a>
          </div>
          <div class="col-md-4 order-md-1 d-flex topper mb-md-0 mb-2 align-items-center text-md-right">
            
            
            </div>
            <div class="pr-md-4 pl-md-0 pl-3 text">
              
            </div>
          </div>
          <div class="col-md-4 order-md-3 d-flex topper mb-md-0 align-items-center">
            
            <div class="text pl-3 pl-md-3">
              
            </div>
          </div>
        </div>
      </div>
    </div>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark ftco-navbar-light" id="ftco-navbar">
      <div class="container d-flex align-items-center">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="oi oi-menu"></span> Menu
        </button>
        <div class="collapse navbar-collapse" id="ftco-nav">
          <ul class="navbar-nav m-auto">
            <li class="nav-item active"><a href="home.php" class="nav-link pl-0">HOME</a></li>
<li class="nav-item active"><a href="pro.php" class="nav-link pl-0">PROFILE</a></li>
<li class="nav-item active"><a href="find_frds.php" class="nav-link pl-0">FINDFRIENDS</a></li>
           <li class="nav-item active"><a href="notification.php" class="nav-link pl-0">NOTIFICATION
            <span><?php echo $total;?>LIKE<?php echo $totalcmt;?>COMMENT
            </span></a></li>
           <li class="nav-item active"><a href="contact.php" class="nav-link pl-0">CONTACT</a></li>
            <li class="nav-item active"><a href="logout.php" class="nav-link pl-0">LOGOUT</a></li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- END nav -->
      <body>
  <table width="100%">
      <tr>

        <td></td>
        <td><?php echo $_SESSION['name']; ?>&nbsp;&nbsp;
          
        
          </tr>



</table>



    
    <section class="hero-wrap hero-wrap-2" style="background-image: url('images/');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
            <h1 class="mb-2 bread">POST</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="index.html"> <!-- <i class="ion-ios-arrow-forward"></i></a></span> <span> <i class="ion-ios-arrow-forward"></i></span></p> -->
          </div>
        </div>
      </div>
    </section>
      <?php
  
  date_default_timezone_set("Asia/Kolkata");
    $user_id=$_SESSION['uid'];
  $date=date('Y-m_d');
   $time=date('g:i a');

if(isset($_POST['submit']) && $_POST['submit']!=''){
      $target_dir = "uploads/";      

  for($i=0; $i<count($_FILES['image']['name']); $i++){  
  $filename= ($_FILES['image']['name'][$i]);
  $uploadok =1;
  $imagefiletype = strtolower(pathinfo($_FILES['image']['name'][$i], PATHINFO_EXTENSION));
  $imageName = $i.time().'.'.$imagefiletype;
  $target_file = $target_dir .$imageName;

  $newimage[]=$imageName;
if(file_exists($target_file))
  {
      $message['image'] = "Already image exists";
      $uploadok = 0;
  }
  if ($_FILES["image"]["size"][$i] > 500000)
  {
      $message['image'] = "File is too large";
      $uploadok = 0;    
  }

  if($imagefiletype != "jpg" && $imagefiletype != "png" && $imagefiletype != "jpeg"  && $imagefiletype != "gif" )
  {
      $uploadok = 0;
      $message['image'] = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    }
   
  else
  {
      if($_FILES["image"]["tmp_name"][$i] != '') {
         
          move_uploaded_file($_FILES["image"]["tmp_name"][$i], $target_file);
  }
      else
      {
          echo "Error uploading file";    
      }
  } 
   

}
      $imgnewfile = implode(',', $newimage);



$sqlposts="INSERT INTO posts(user_id,post_image,date,time)values
('$user_id','".$imgnewfile."','$date','$time')";
//echo $sqlposts;

if($conn->query($sqlposts)==TRUE)  
{
    echo "Upload successfully";
}
else
{
  //echo "failed";
}
}

?>
    <h2> Image Upload</h2>
<body>
   <form  method="POST" enctype="multipart/form-data">
    <input type="file" multiple name="image[]" value="$filename"/>
  <!-- <input type="hidden" name="fullimagename" value="<?php // echo $row['post_image'];?>"> -->
<input type="submit" value="Submit" id="submit" name="submit" />


  </form>

    
    <section class="ftco-section bg-light">
      <div class="container">
        <div class="row">
          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              
          </div>
          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
             
              <!-- <div class="text bg-white p-4">
                <h3 class="heading"><a href="#">Scary Thing That You Don’t Get Enough Sleep</a></h3>
                <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
                <div class="d-flex align-items-center mt-4">
                  <p class="mb-0"><a href="#" class="btn btn-primary">Read More <span class="ion-ios-arrow-round-forward"></span></a></p>
                  <p class="ml-auto mb-0">
                    <a href="#" class="mr-2">Admin</a>
                    <a href="#" class="meta-chat"><span class="icon-chat"></span> 3</a>
                  </p>
                </div>
              </div> -->
            </div>
          </div>
          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
             <!--  <a href="blog-single.html" class="block-20 d-flex align-items-end justify-content-end" style="background-image: url('images/image_3.jpg');">
                <div class="meta-date text-center p-2">
                  <span class="day">18</span>
                  <span class="mos">September</span>
                  <span class="yr">2019</span>
                </div>
              </a>
              <div class="text bg-white p-4">
                <h3 class="heading"><a href="#">Scary Thing That You Don’t Get Enough Sleep</a></h3>
                <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
                <div class="d-flex align-items-center mt-4">
                  <p class="mb-0"><a href="#" class="btn btn-primary">Read More <span class="ion-ios-arrow-round-forward"></span></a></p>
                  <p class="ml-auto mb-0">
                    <a href="#" class="mr-2">Admin</a>
                    <a href="#" class="meta-chat"><span class="icon-chat"></span> 3</a>
                  </p>
                </div>
              </div> -->
            </div>
          </div>

          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
             <!--  <a href="blog-single.html" class="block-20 d-flex align-items-end justify-content-end" style="background-image: url('images/image_4.jpg');">
                <div class="meta-date text-center p-2">
                  <span class="day">18</span>
                  <span class="mos">September</span>
                  <span class="yr">2019</span>
                </div>
              </a>
              <div class="text bg-white p-4">
                <h3 class="heading"><a href="#">Scary Thing That You Don’t Get Enough Sleep</a></h3>
                <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
                <div class="d-flex align-items-center mt-4">
                  <p class="mb-0"><a href="#" class="btn btn-primary">Read More <span class="ion-ios-arrow-round-forward"></span></a></p>
                  <p class="ml-auto mb-0">
                    <a href="#" class="mr-2">Admin</a>
                    <a href="#" class="meta-chat"><span class="icon-chat"></span> 3</a>
                  </p>
                </div>
              </div> -->
            </div>
          </div>
          <div class="col-md-4 ftco-animate">
            <!-- <div class="blog-entry">
              <a href="blog-single.html" class="block-20 d-flex align-items-end justify-content-end" style="background-image: url('images/image_5.jpg');">
                <div class="meta-date text-center p-2">
                  <span class="day">18</span>
                  <span class="mos">September</span>
                  <span class="yr">2019</span>
                </div>
              </a>
              <div class="text bg-white p-4">
                <h3 class="heading"><a href="#">Scary Thing That You Don’t Get Enough Sleep</a></h3>
                <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
                <div class="d-flex align-items-center mt-4">
                  <p class="mb-0"><a href="#" class="btn btn-primary">Read More <span class="ion-ios-arrow-round-forward"></span></a></p>
                  <p class="ml-auto mb-0">
                    <a href="#" class="mr-2">Admin</a>
                    <a href="#" class="meta-chat"><span class="icon-chat"></span> 3</a>
                  </p>
                </div>
              </div> -->
            </div>
          </div>
          <div class="col-md-4 ftco-animate">
            <!-- <div class="blog-entry">
              <a href="blog-single.html" class="block-20 d-flex align-items-end justify-content-end" style="background-image: url('images/image_6.jpg');">
                <div class="meta-date text-center p-2">
                  <span class="day">18</span>
                  <span class="mos">September</span>
                  <span class="yr">2019</span>
                </div>
              </a>
              <div class="text bg-white p-4">
                <h3 class="heading"><a href="#">Scary Thing That You Don’t Get Enough Sleep</a></h3>
                <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
                <div class="d-flex align-items-center mt-4">
                  <p class="mb-0"><a href="#" class="btn btn-primary">Read More <span class="ion-ios-arrow-round-forward"></span></a></p>
                  <p class="ml-auto mb-0">
                    <a href="#" class="mr-2">Admin</a>
                    <a href="#" class="meta-chat"><span class="icon-chat"></span> 3</a>
                  </p>
                </div>
              </div>
            </div> -->
          </div>
        </div>
        <div class="row no-gutters my-5">
          <div class="col text-center">
            
          </div>
        </div>
      </div>
    </section>
    
    
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>


