<?php
session_start();
include('config.php');

   
       
       $sqldelpost="DELETE  FROM comments where comment_id='".$_REQUEST['comment_id']."'";
       echo $sqldelpost;
       $resultp=$conn->query($sqldelpost);
       	//echo $resultp;exit;

?>

