<?php

//extract($_REQUEST
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "facebook";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$cmt = $_POST['cmt_area'];
// $postid=$_REQUEST['post_id'];
// $userid=$_REQUEST['user_id'];



$sql = "INSERT INTO cmt_table (post_id,user_id,comment) VALUES ('" . $_SESSION['pst_id'] . "','" . $_SESSION['u_id'] . "','" . $cmt . "')";
//echo $sql;

if ($conn->query($sql) == TRUE) {
//    $cmt_dis = unserialize($cmt);
//print_r($cmt_dis);
//    $_SESSION['comment'] = $cmt_dis;
//echo "chandrasekar";
    echo "success";
} else {
    echo "Error: ";
}
?>
