<?php
session_start();
error_reporting(0);
include('config.php');
include('check_session.php');
$loguserid=$_SESSION['uid'];

 function time_stamp()
 
 {     $time_difference= time - $session_time();
     $seconds=$time_difference;
     $minutes= round($time_difference/60);
    $hours = round($time_difference / 3600 ); 
 $days = round($time_difference / 86400 ); 
 $weeks = round($time_difference / 604800 ); 
 $months = round($time_difference / 2419200 ); 
 $years = round($time_difference / 29030400 ); 

 if($seconds <= 60)
 {
 echo"$seconds seconds ago"; 
 }
 else if($minutes <=60)
 {
    if($minutes==1)
    {
      echo"one minute ago"; 
     }
    else
    {
    echo"$minutes minutes ago"; 
    }
 }
 else if($hours <=24)
 {
    if($hours==1)
    {
    echo"one hour ago";
    }
   else
   {
   echo"$hours hours ago";
 }
 }
 else if($days <=7)
 {
   if($days==1)
    {
    echo"one day ago";
    }
   else
   {
   echo"$days days ago";
   }


   
 }
 else if($weeks <=4)
 {
   if($weeks==1)
    {
    echo"one week ago";
    }
   else
   {
   echo"$weeks weeks ago";
   }
  }
 else if($months <=12)
 {
    if($months==1)
    {
    echo"one month ago";
    }
   else
   {
  echo"$months months ago";
 }

}

 if($years==1)
    {
    echo"one year ago";
    }
   else
   {
   echo"$years years ago";
   }

 
} 




?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <table width="100%">
      <tr>

        <td></td>
        <!-- <td><?php echo $_SESSION['name']; ?>&nbsp;&nbsp;
          (<a href="logout.php">Logout</a>)</td>
         -->
          </tr>



</table>
    <title> Admin Homepage</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
    
<div class="py-md-5 py-4 border-bottom">
      <div class="container">
        <div class="row no-gutters d-flex align-items-start align-items-center px-3 px-md-0">
          <div class="col-md-4 order-md-2 mb-2 mb-md-0 align-items-center text-center">
      <a class="navbar-brand" href="index.php">ITFMEDIA<span></span>
      </a>
      
      <span style="font-size:15px;color:#F00;"><?php echo $_SESSION['']; ?></span>
      
      
          </div>
          <div class="col-md-4 order-md-1 d-flex topper mb-md-0 mb-2 align-items-center text-md-right">
            
              <span class=></span>
            </div>
            <div class="pr-md-4 pl-md-0 pl-3 text">
              <p class="con"><span></span> <span></span></p>
              <p class="con"></p>
            </div>
          </div>
          <?php
         if(empty($_SESSION['id']))
         {
          ?>
      



          <div class="col-md-4 order-md-3 d-flex topper mb-md-0 align-items-center">
            <span class=></span></div>
            <div class="text pl-3 pl-md-3">
              <p class="hr"><span></span></p>
              <p class="time"><span></span> <span></span> </p>
            </div>
          </div>
          <?php

         }
          
          else
          {
            ?>  

<div class="col-md-4 order-md-3 d-flex topper mb-md-0 align-items-center">
            <div class="icon d-flex justify-content-center align-items-center"><span class="icon-paper-plane"></span></div>
            <div class="text pl-3 pl-md-3">
      <p class="hr"><span><?php echo $_SESSION['name']; ?></span></p>
<p class="time"><span><a href=""></a></span> </p>
            </div>
          </div>
          <?php

         }
          ?>
        </div>
      </div>
    </div>
  
  
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark ftco-navbar-light" id="ftco-navbar">
      <div class="container d-flex align-items-center">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="oi oi-menu"></span> Menu
        </button>
        <div class="collapse navbar-collapse" id="ftco-nav">
          <ul class="navbar-nav m-auto">
  
    <li class="nav-item"><a href="Adminprofile.php" class="nav-link">ADMINPROFILE</a></li>
    <li class="nav-item"><a href="adminposts.php" class="nav-link">ADMINPOSTS</a></li>
    <li class="nav-item"><a href="addgallery.php" class="nav-link">ADDGALLERY</a></li>
    <li class="nav-item active"><a href="Adusercds.php" class="nav-link pl-0">VIEWUSERRECORDS</a></li>
    <li class="nav-item"><a href="adminnotification.php" class="nav-link">AdminNotification</a></li>
      <li class="nav-item"><a href="contactas.php" class="nav-link">Contact us</a></li>
    <li class="nav-item"><a href="logout.php" class="nav-link">LOGOUT</a></li>
          </ul>
        </div>
      </div>
    </nav>
    

    <!-- END nav -->
    
		

    <section class="hero-wrap hero-wrap-2" style="background-image: url('images/');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
            <h1 class="mb-2 bread">ADMINHOME</h1>
            
          </div>
        </div>
      </div>
    </section>

		<section class="ftco-section ftco-no-pt ftco-no-pb">
			<div class="container">

				<div class="row no-gutters">
					<div class="col-md-5 p-md-5 img img-2 mt-5 mt-md-0" style="background-image: url(images/);">
					</div>


					<div class="col-md-7 wrap-about py-4 py-md-5 ftco-animate">
	          <div class="heading-section mb-5">
	          	<div class="pl-md-5 ml-md-5 pt-md-5">
		          	<span class="subheading mb-2"> WELCOME TO ADMINHOME PAGE</span>
                  <h2 class="mb-2" style="font-size: 10px;">
                    <div id= "container">
                      <div id="left-nav">
                        <?php
                                    $sql_home = "SELECT * FROM `smd`";
                                    $result_name = $conn->query($sql_home);

                                    $post_image_qry = "SELECT * FROM `posts` order by post_image desc";
                                    $post_image_arr = $conn->query($post_image_qry);

                                    while ($post_image_res = $post_image_arr->fetch_assoc()) {
                                      ?>
                                      <form method="POST" id="register_form">

                                        <img src="uploads/<?php echo $post_image_res['post_image'];?>">
 <a href="comment1.php?post_id=<?php echo $post_image_res['post_id'];?>&&user_id=<?php echo $post_image_res['user_id'];?>">COMMENT</a>
 <a href="deletepost.php?post_id=<?php echo $post_image_res['post_id'];?>&&user_id=<?php echo $post_image_res['user_id'];?>">DELETEPOST</a>
        <?php   
          $sqlctlikes="SELECT count(*) as total from likes where post_id='".$post_image_res['post_id']."'";
            $resultcount=$conn->query($sqlctlikes);
            $rowcnt=$resultcount->fetch_assoc();
                $total=$rowcnt['total'];
                      ?>
                        <span class="span_cls">
                          <input type="hidden" name="vals" class="num" value="<?php echo $post_image_res['post_id'].",".$post_image_res['user_id'];?>"> 
                          <h3>Like<?php
                          if($total!=0){
                      echo "(" . $total . ")";
                          }
                          ?></h3>
                          <?php
                              $sql = "SELECT * from cmt_table where `post_id`='".$post_image_res['post_id']."'";
                              $result222=$conn->query($sql);
                              while($row=$result222->fetch_assoc())
                              {
                                echo $row['comment'] .'<br/>';
                                ?>
                                <?php
                              }
                                ?>
                        </span>
                        


                                     <?php   
                                    }
                                    ?>
  	            </div>
	          </div>
	          <div class="pl-md-5 ml-md-5 mb-5">
							
								<div class="img" style="background-image: url(images/doc1.jpeg);"></div>
								<div class="text pl-3">
									<h3 class="mb-0"></h3>
									<span class="position"></span>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

		<section class="ftco-section ftco-no-pt ftco-no-pb">
			<div class="container-fluid px-md-0">
				<div class="row no-gutters">
					<div class="col-md-3 d-flex align-items-stretch">
						
					</div>
					<div class="col-md-6 d-flex align-items-stretch">
						<div class="consultation consul w-100 px-4 px-md-5">
							<div class="text-center">
								<h3 class="mb-4">Free Consultation</h3>
							</div>
							<form action="#" class="appointment-form">
								<div class="row">
									<div class="col-md-12 col-lg-6 col-xl-4">
										<div class="form-group">
				    					<!-- <input type="text" class="form-control" placeholder="First Name"> -->
				    				</div>
									</div>
									<div class="col-md-12 col-lg-6 col-xl-4">
										<div class="form-group">
				    					<!-- <input type="text" class="form-control" placeholder="Last Name"> -->
				    				</div>
									</div>
									<div class="col-md-12 col-lg-6 col-xl-4">
										<div class="form-group">
				    					<div class="form-field">
		          					<div class="select-wrap">
		                      <div class="icon"><span class="ion-ios-arrow-down"></span></div>
		                      <!-- <select name="" id="" class="form-control">
		                      	<option value="">Department</option>
		                        <option value="">Neurology</option>
		                        <option value="">Cardiology</option>
		                        <option value="">Dental</option>
		                        <option value="">Ophthalmology</option>
		                        <option value="">Other Services</option>
		                      </select> -->
		                    </div>
				              </div>
				    				</div>
									</div>
									<div class="col-md-12 col-lg-6 col-xl-4">
										<div class="form-group">
				    					<div class="input-wrap">
				            		<div class="icon"><span class="ion-md-calendar"></span></div>
				            		<!-- <input type="text" class="form-control appointment_date" placeholder="Date"> -->
			            		</div>
				    				</div>
									</div>
									<div class="col-md-12 col-lg-6 col-xl-4">
										<div class="form-group">
				    					<div class="input-wrap">
				            		<div class="icon"><span class="ion-ios-clock"></span></div>
				            		<!--   -->
			            		</div>
				    				</div>
									</div>
									<div class="col-md-12 col-lg-6 col-xl-4">
										<div class="form-group">
				              px-4">
				            </div>
									</div>
								</div>
		    			</form>
		    	  </div>
					</div>
					<div class="col-md-3 d-flex align-items-stretch">
						 <div class="row justify-content-center mb-5 pb-5">
            <form action="" method="POST" enctype="multipart/form-data">
              

                  </form>
                </div>
					</div>
				</div>
			</div>
		</section>
		

    <section class="ftco-section ftco-services">
    	<div class="container">
    		<div class="row justify-content-center mb-5 pb-2">
          <div class="col-md-8 text-center heading-section ftco-animate">
          	
            
          </div>
        </div>
        <div class="row">
        	<div class="col-md-3 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block text-center">
              <div class="icon d-flex justify-content-center align-items-center">
            		
              </div>
              
          </div>
          <div class="col-md-3 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block text-center">
              <div class="icon d-flex justify-content-center align-items-center">
            		
              </div>
              
            </div>      
          </div>
          <div class="col-md-3 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block text-center">
              <div class="icon d-flex justify-content-center align-items-center">
            		
              </div>
             
            </div>      
          </div>
					
					<div class="col-md-3 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block text-center">
              <div class="icon d-flex justify-content-center align-items-center">
            
            </div>
          </div>
          <div class="col-md-3 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block text-center">
              <div class="icon d-flex justify-content-center align-items-center">
            
            </div>      
          </div>
          <div class="col-md-3 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block text-center">
              <div class="icon d-flex justify-content-center align-items-center">
            
            </div>      
          </div>
          <div class="col-md-3 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block text-center">
              <div class="icon d-flex justify-content-center align-items-center">
            		
              </div>
              <div class="media-body p-2 mt-3">
            
            </div>      
          </div>
          <div class="col-md-3 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block text-center">
              <div class="icon d-flex justify-content-center align-items-center">
            	
              </div>
              <div class="media-body p-2 mt-3">
                
            </div>      
          </div>
        </div>
    	</div>
    </section>

    <section class="ftco-section intro" style="background-image: url(images/);" data-stellar-background-ratio="0.5">
    	<div class="container">
    		<div class="row">
    			<div class="col-md-6">

    			</div>
    		</div>
    	</div>
    </section>
		
		<section class="ftco-section">
			<div class="container">
				<div class="row justify-content-center mb-5 pb-2">
          <div class="col-md-8 text-center heading-section ftco-animate">
          	
          </div>
        </div>	
				<div class="row">
					<div class="col-md-6 col-lg-3 ftco-animate">
						<div class="staff">
							<div class="img-wrap d-flex align-items-stretch">
								<div class="img align-self-stretch" style="background-image: url(images/);"></div>
							</div>
							<div class="text pt-3 text-center">
								
								
									
	              </div>
							</div>
						</div>
					</div>
					<div class="col-md-6 col-lg-3 ftco-animate">
						<div class="staff">
							<div class="img-wrap d-flex align-items-stretch">
								<div class="img align-self-stretch" style="background-image: url(images/);"></div>
							</div>
							<div class="text pt-3 text-center">
								
	              </div>
							</div>
						</div>
					</div>
					<div class="col-md-6 col-lg-3 ftco-animate">
						<div class="staff">
							<div class="img-wrap d-flex align-items-stretch">
								<div class="img align-self-stretch" style="background-image: url(images/);"></div>
							</div>
							<div class="text pt-3 text-center">
								
	              </div>
							</div>
						</div>
					</div>
					<div class="col-md-6 col-lg-3 ftco-animate">
						<div class="staff">
							<div class="img-wrap d-flex align-items-stretch">
						<div class="img align-self-stretch" style="background-image: url(images/);"></div>
							</div>
							<div class="text pt-3 text-center">
							
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

    <section class="ftco-section testimony-section bg-light">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-2">
          <div class="col-md-8 text-center heading-section ftco-animate">
          	
          </div>
        </div>
        <div class="row ftco-animate justify-content-center">
          <div class="col-md-12">
            <div class="carousel-testimony owl-carousel">
              <div class="item">
                <div class="testimony-wrap d-flex">
                  <div class="user-img" style="background-image: url(images/)">
                  </div>
                  <div class="text pl-4 bg-light">
                  	
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap d-flex">
                  <div class="user-img" style="background-image: url(images/)">
                  </div>
                  <div class="text pl-4 bg-light">
                  	
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap d-flex">
                  <div class="user-img" style="background-image: url(images/)">
                  </div>
                  <div class="text pl-4 bg-light">
                  	<span class="quote d-flex align-items-center justify-content-center">
                      
                    </span>
                   
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap d-flex">
                  <div class="user-img" style="background-image: url(images/)">
                  </div>
                  <div class="text pl-4 bg-light">
                  	<span class="quote d-flex align-items-center justify-content-center">
                      
                    </span>
                   
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap d-flex">
                  <div class="user-img" style="background-image: url(images/)">
                  </div>
                  <div class="text pl-4 bg-light">
                  	<span class="quote d-flex align-items-center justify-content-center">
                      
                    </span>
                    
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-intro" style="background-image: url(images/bg_3.jpg);" data-stellar-background-ratio="0.5">
			<div class="overlay"></div>
			<div class="container">
				<div class="row">
					<div class="col-md-9">
						<h2>We Provide Free Dental Care Consultation</h2>
						<p class="mb-0">Your Health is Our Top Priority with Comprehensive, Affordable medical.</p>
						<p></p>
					</div>
					<div class="col-md-3 d-flex align-items-center">
						<p class="mb-0"><a href="#" class="btn btn-secondary px-4 py-3">Free Consutation</a></p>
					</div>
				</div>
			</div>
		</section>

    <section class="ftco-section">
    	<div class="container">
    		<div class="row justify-content-center mb-5 pb-2">
          <div class="col-md-8 text-center heading-section ftco-animate">
          	<span class="subheading"></span>
            <h2 class="mb-4"></h2>
          </div>
        </div>
    		<div class="row">
        	<div class="col-md-3 ftco-animate">
        		
        			
        			
        		</div>
        	</div>
        	<div class="col-md-3 ftco-animate">
        		
        	</div>
        	<div class="col-md-3 ftco-animate">
        		
        	</div>
        	<div class="col-md-3 ftco-animate">
        		
        	</div>
        </div>
    	</div>
    </section>

		<section class="ftco-section bg-light">
			<div class="container">
				<div class="row justify-content-center mb-5 pb-2">
          <div class="col-md-8 text-center heading-section ftco-animate">
          	<span class="subheading"></span>
            <h2 class="mb-4"></h2>
            
          </div>
        </div>
				<div class="row">
          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
             
           
              <div class="text bg-white p-4">
           
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              
                            <div class="text bg-white p-4">
              
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              
                </div>
              </a>
              <div class="text bg-white p-4">
              
	                          </div>
              </div>
            </div>
          </div>
        </div>
			</div>
		</section>

		
    
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="js/main.js"></script>


 
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script type="text/javascript">
         $('span.span_cls').on('click',function(event){
          
          var lks_id =  $('input.num', this).val();
      
          var split_var = lks_id.split(",");
          var post_id = split_var[0];
          var usr_id = split_var[1];
           //console.log(post_id);
          //  console.log(split_var[1]);
                  var form_data =
             'p_id='+post_id+
             '&u_id='+usr_id;
             //alert(form_data);         


         $.ajax({
               url: 'admin_like.php',              
               //POST method is used
               type: "POST",    
               //pass the data        
               data: form_data,                
               //success
               success: function (html) {            
                   //if process.php returned 1/true (
                   if (html=='success') {          
                       // $('#message').html('Successfully comment !');
                      // $('#register_form').load('http://localhost/dentista/home.php');
                   } else {
                  // $('#message').html('errosss !');
                   }
               }

       });
            });
</script>
  </body>
</html>
<style>
   
   span.span_cls {
   cursor: pointer;
       text-decoration: underline;
   color: blue;
       font-size: 15px;
   font-weight: bold;
}
</style>
