<?php
error_reporting(0);
$err=0;
$msh=array();
$srs=0;
$mshs=array();
include 'config.php';
if (isset($_POST['galsubmit'])) {

        /////multiple
        $target_dir = "gallery/";       
        for ($i = 0; $i < count($_FILES['image']['name']); $i++) {
            $filename = ($_FILES['image']['name'][$i]); 
            $uniquesavename1 = $i . time() . uniqid(rand(), 0, 4);
            echo $uniquesavename1;
            $destFile = $target_dir . $uniquesavename1 . '.jpg';
            $imagenames = $uniquesavename1 . '.jpg';
            $newimage[] = $imagenames;
            if ($_FILES["image"]["tmp_name"][$i] != '') {
                move_uploaded_file($_FILES["image"]["tmp_name"][$i], $destFile);
            
            } //else {
                //echo "Error uploading file";               
           // }
        $allimgname .=$imagenames.',';        
        $rtrim = rtrim($allimgname,',');
            }           
        
$insert = "INSERT INTO `gallery` (`imagefile`) VALUES ('" . $rtrim . "')";
echo $insert;

  if ($conn->query($insert)) {
      $srs=1;
$mshs['mm']="Image Added Successfully";
  //echo "Image Added Successfully";                
  } 



  else {                                
      $srs=0;
$mshs['mm']="Image Not Added Successfully";
  //echo "Not Added";
}
}   

?>



<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Add Gallery</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
    <div class="py-md-5 py-4 border-bottom">
      <div class="container">
        <div class="row no-gutters d-flex align-items-start align-items-center px-3 px-md-0">
          <div class="col-md-4 order-md-2 mb-2 mb-md-0 align-items-center text-center">
            <a class="navbar-brand" href="index.html">ITFMEDIA<span></span></a>
          </div>
          <div class="col-md-4 order-md-1 d-flex topper mb-md-0 mb-2 align-items-center text-md-right">
            <div class="">
              <span class=""></span>
            </div>
            <div class="pr-md-4 pl-md-0 pl-3 text">

              
            </div>
          </div>
          <div class="col-md-4 order-md-3 d-flex topper mb-md-0 align-items-center">
            <div class=""><span class=></span></div>
            <div class="text pl-3 pl-md-3">
              <p class="hr"><span></span></p>
              <p class="time"><span></span> <span></span> </p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark ftco-navbar-light" id="ftco-navbar">
      <div class="container d-flex align-items-center">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="oi oi-menu"></span> Menu
        </button>
        <div class="collapse navbar-collapse" id="ftco-nav">
          <ul class="navbar-nav m-auto">
            <li class="nav-item"><a href="Adminhome.php" class="nav-link pl-0">ADMINHOME</a></li>
            <li class="nav-item"><a href="adminprofile.php" class="nav-link">ADMINPROFILE</a></li>
            <li class="nav-item"><a href="viewgallery.php" class="nav-link">VIEWGALLERY</a></li>
            <li class="nav-item"><a href="Adusercds.php" class="nav-link">VIEW USER RECORDS</a></li>
            <li class="nav-item"><a href="adminnotification.php" class="nav-link">ADMINNOTIFICATION</a></li>
            <li class="nav-item"><a href="logout.php" class="nav-link">LOGOUT</a></li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- END nav -->
    <section class="hero-wrap hero-wrap-2" style="background-image: url('images/');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
            <h1 class="mb-2 bread">ADDGALLERY</h1>
            
          </div>
        </div>
      </div>
    </section>
    
    <section class="hero-wrap hero-wrap-2" style="background-image: url('images/');" data-stellar-background-ratio="0.5">
      <div class=""></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
            <h1 class="mb-2 bread"></h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="index.html"> <i class=""></i></a></span> <span> <i class=""></i></span></p>
          </div>
        </div>
      </div>
    </section>
    
    <section class="ftco-section ftco-services">
      <div class="container">
        <div class="row">
          <div class="col-md-4 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block">
              <div class="img w-100" style="background-image: url(images/);"></div>
              <div class="media-body p-2 mt-3">
                                </div>







            </div>
          </div>
          <div class="col-md-4 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block">
              <div class="img w-100" style="background-image: url(images/);"></div>
              <div class="media-body p-2 mt-3">
                
              </div>
            </div>      
          </div>
          <div class="col-md-4 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block">
              <div class="img w-100" style="background-image: url(images/);"></div>
              <div class="media-body p-2 mt-3">
                <h3 class="heading"></h3>
                <p class="breadcrumbs" data-scrollax=" properties: { translateY: '70%', opacity: 1.6}"><span class="mr-2"><a href="Adminhome.php">Home</a></span>| <span><a href="Logout.php">Logout</a></span></p>
    <h1 class="mb-3" data-scrollax=" properties: { translateY: '70%', opacity: .9}">Welcome to Gallery</h1>
                
              </div>
            </div>      
          </div>
          
          <div class="col-md-4 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block">
              <div class="img w-100" style="background-image: url(images/);"></div>
              <div class="media-body p-2 mt-3">
                <h3 class="heading"></h3>
                
              </div>
            </div>
          </div>
          <div class="col-md-4 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block">
              <div class="img w-100" style="background-image: url(images/);"></div>
              <div class="media-body p-2 mt-3">
                <h3 class="heading"></h3>
              
              </div>
            </div>      
          </div>
          <div class="col-md-4 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block">
              <div class="img w-100" style="background-image: url(images/);"></div>
              <div class="media-body p-2 mt-3">
                
                  <div class="row justify-content-center mb-5 pb-5">
            <form action="" method="POST" enctype="multipart/form-data" class="add_gallery_frm">
                <?php
                if($_POST['galsubmit']=='Add'){
                    
                    if($srs=0){
                        echo '<span style="color:red;">' . $mshs['mm'] . '</span>';
                    }else{
                        echo '<span style="color:green;">' . $mshs['mm'] . '</span>';
                    }
                }
                ?>
                <br>
                        <div id= "image1" class="container-login100-form-btn m-t-20"></div>

                            <div>
                                <button type="button" id="addmore" class="btn btn-primary px-4 py-2">
                                    Add more                                    
                                </button>
                            </div>
                        <br>
                            <div>
                                <button type="button" id="remove" class="btn btn-primary px-4 py-2">
                                    Remove                                    
                                </button>       
                            </div>
                        <br>
                        
                        <input type ="submit" name="galsubmit" class="btn btn-primary px-4 py-2" value="Add"><br>
                        <br>
                <input type="button" value="Go Back" class="btn btn-primary px-4 py-2" onclick="window.location.href='Adminhome.php'"/>
                
                                   
            </form>
            </div>



                
              </div>
            </div>      
          </div>
          <div class="col-md-4 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block">
              <div class="img w-100" style="background-image: url(images/);"></div>
              <div class="media-body p-2 mt-3">
                <h3 class="heading"></h3>
                </div>
            </div>      
          </div>



          <div class="col-md-4 d-flex services align-self-stretch p-4 ftco-animate">
            <div class="media block-6 d-block">
              <div class="img w-100" style="background-image: url(images/);"></div>
              <div class="media-body p-2 mt-3">
                 </div>
            </div>      
          </div>
        </div>
      </div>
    </section>
    
   
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
         <script type="text/javascript">

            $(document).ready(function () {

                $('#addmore').click(function () {
                    $(this).after($("<div/>", {id: 'image1'}).append($("<input/>", {name: 'image[]', type: 'file', id: 'image'}), $("<br/><br/>")));

                });

                $("#remove").click(function () {
                    $("#image1").remove();
                });


            });
            </script>
            




  </body>
</html>