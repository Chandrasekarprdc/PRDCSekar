<?php
session_start();
include('config.php');
$pid = $_POST['p_id'];
$uid=$_SESSION['uid'];


	// $slct_query="SELECT user_id from likes where user_id='".$uid."'";
	// //echo $slct_query;
	// $result=$conn->query($slct_query);

	$slct_query="SELECT id FROM `likes` WHERE user_id=$uid AND post_id=$pid";
	$result=$conn->query($slct_query);

	$row = $result -> fetch_array(MYSQLI_ASSOC);
	if($row['id']==''){

		$sql="INSERT into likes(post_id,user_id)values('$pid','$uid')";
		if($conn->query($sql)==TRUE)
		{
			echo "success";

		}else{
			echo "error";

		}
		$conn->close();	 
	}



?>


