<?php
error_reporting(0);
$err=0;
$msh=array();
$srs=0;
$mshs=array();
include 'config.php';
if (isset($_POST['galsubmit'])) {

        /////multiple
        $target_dir = "gallery/";       
        for ($i = 0; $i < count($_FILES['image']['name']); $i++) {
            $filename = ($_FILES['image']['name'][$i]); 
            $uniquesavename1 = $i . time() . uniqid(rand(), 0, 4);
            $destFile = $target_dir . $uniquesavename1 . '.jpg';
            $imagenames = $uniquesavename1 . '.jpg';
            $newimage[] = $imagenames;
            if ($_FILES["image"]["tmp_name"][$i] != '') {
                move_uploaded_file($_FILES["image"]["tmp_name"][$i], $destFile);
            
            } //else {
                //echo "Error uploading file";               
           // }
        $allimgname .=$imagenames.',';        
        $rtrim = rtrim($allimgname,',');
            }           
        
$insert = "INSERT INTO `gallery` (`Image_Name`) VALUES ('" . $rtrim . "')";

  if ($connection->query($insert)) {
      $srs=1;
$mshs['mm']="Image Added Successfully";
  ///echo "Image Added Successfully";                
  } else {                                
      $srs=0;
$mshs['mm']="Image Not Added Successfully";
  //echo "Not Added";
}
}   

?>
<?php
include 'config.php';


?>
<!DOCTYPE php>
<html lang="en">
    <head>
        <title>Welcome to Gallery</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
       <!-- <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,500,600,700" rel="stylesheet">-->
    
    </head>
    <body>
 <div class="row justify-content-center mb-5 pb-5">
    <form action="" method="POST" enctype="multipart/form-data" class="add_gallery_frm">
                <?php
                if($_POST['galsubmit']=='Add'){
                    
                    if($srs=0){
                        echo '<span style="color:red;">' . $mshs['mm'] . '</span>';
                    }else{
                        echo '<span style="color:green;">' . $mshs['mm'] . '</span>';
                    }
                }
                ?>
                <br>
                        <div id= "image1" class="container-login100-form-btn m-t-20"></div>

                            <div>
                                <button type="button" id="addmore" class="btn btn-primary px-4 py-2">
                                    Add more                                    
                                </button>
                            </div>
                        <br>
                            <div>
                                <button type="button" id="remove" class="btn btn-primary px-4 py-2">
                                    Remove                                    
                                </button>       
                            </div>
                        <br>
                        
                        <input type ="submit" name="galsubmit" class="btn btn-primary px-4 py-2" value="Add"><br>
                        <br>
               
                
                                   
            </form>
            </div>


  </body>
</html>


        <script type="text/javascript">

            $(document).ready(function () {

                $('#addmore').click(function () {
                    $(this).after($("<div/>", {id: 'image1'}).append($("<input/>", {name: 'image[]', type: 'file', id: 'image'}), $("<br/><br/>")));

                });

                $("#remove").click(function () {
                    $("#image1").remove();
                });


            });
            </script>
            

  