<?php
session_start();
include('config.php');


$pid = $_POST['p_id'];
$uid=$_POST['u_id'];


	$slct_query="SELECT user_id from likes where user_id='".$uid."'";
	//echo $slct_query;
	$result=$conn->query($slct_query);


	 if($result->num->rows> 0){
		$sql="INSERT into likes(post_id,user_id)values('$pid','$uid')";
		echo $sql;
		if($conn->query($sql)==TRUE)
		{
			echo "success";

		}else{
			echo "error";

		}
		$conn->close();
	 }




?>

