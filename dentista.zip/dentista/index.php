<script type="text/javascript">
      function likeclick(element){
        var postid=element.id;
        var userid=<?php echo $loguserid;?>
        $.ajax({
            type:'POST',
            url:'likes.php',
            data:{"userid":user_id,"postid":post_id},
            success:function(content)
            {
              $(#like).html(content);
              
            }

        });
      }




  </script>
